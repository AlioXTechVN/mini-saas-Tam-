# -*- coding: utf-8 -*-
"""Genere une demo HTML statique (anglais uniquement) a partir du mini-SaaS Parc Immo :
- selectionne ~50 coproprietes representatives (variete de classes DPE, quelques flagships
  avec plan de decarbonation complet) parmi les 803 deja anonymisees ;
- copie ces lignes (+ tables liees) dans une base SQLite filtree, autonome ;
- reutilise les fonctions existantes de db.py (stats_parc, chercher_copros, fiche_copro,
  catalogue_decarbonation) pointees sur cette base filtree, pour garantir des chiffres
  coherents avec le vrai mini-SaaS ;
- rend des fichiers .html autonomes (pas de serveur, pas de formulaires actifs) avec Jinja2,
  en reutilisant les memes templates et le module i18n.py (langue forcee "en").
Sortie : dossier static_demo_en/ (index.html, properties.html, gestes.html,
properties/<ref>.html x50, static/).
"""
import os
import random
import re
import shutil
import sqlite3
import sys

sys.stdout.reconfigure(encoding="utf-8")
random.seed(7)

BASE = os.path.dirname(os.path.abspath(__file__))
SRC_DB = os.path.join(BASE, "data", "parc.db")
OUT = os.path.join(BASE, "static_demo_en")
FILTERED_DB = os.path.join(BASE, "_tmp_demo50.db")
N_CIBLE = 50

# ---------------- 1) selection de 50 coproprietes representatives ----------------
ALLOCATION = {"A": 2, "B": 4, "C": 12, "D": 10, "E": 12, "F": 6, "G": 4}
FLAGSHIP_REFS = ["3064.1"]  # exemple deja verifie manuellement (argumentaire complet)

con = sqlite3.connect(SRC_DB)
con.row_factory = sqlite3.Row

selection = []
for ref in FLAGSHIP_REFS:
    r = con.execute("SELECT row_id FROM copros WHERE ref=?", (ref,)).fetchone()
    if r:
        selection.append(r["row_id"])

for classe, n in ALLOCATION.items():
    deja = len([1 for rid in selection if con.execute(
        "SELECT pire_dpe FROM prioritaires WHERE row_id=?", (rid,)).fetchone() == (classe,)])
    besoin = max(0, n - deja)
    if besoin == 0:
        continue
    rows = con.execute("""
        SELECT p.row_id FROM prioritaires p WHERE p.pire_dpe=? AND p.row_id NOT IN ({})
        ORDER BY p.score DESC""".format(",".join(map(str, selection)) or "-1"), (classe,)).fetchall()
    pool = [r["row_id"] for r in rows]
    # melange dans le tiers superieur (scores eleves) pour varier villes/energies sans
    # tomber uniquement sur les cas les plus extremes
    top = pool[:max(besoin * 3, besoin)]
    random.shuffle(top)
    selection.extend(top[:besoin])

selection = selection[:N_CIBLE]
print(f"Coproprietes selectionnees : {len(selection)}")

# ---------------- 2) construction de la base filtree ----------------
if os.path.exists(FILTERED_DB):
    os.remove(FILTERED_DB)
dst = sqlite3.connect(FILTERED_DB)
dst.execute(f"ATTACH DATABASE '{SRC_DB}' AS src")

schema_sql = con.execute(
    "SELECT sql FROM sqlite_master WHERE type='table' AND sql IS NOT NULL"
    " AND name != 'sqlite_sequence'").fetchall()
for (sql,) in schema_sql:
    dst.execute(sql)

ids_sql = ",".join(map(str, selection))
bg_rows = con.execute(f"SELECT DISTINCT batiment_groupe_id FROM liens WHERE row_id IN ({ids_sql})").fetchall()
bg_ids = [r["batiment_groupe_id"] for r in bg_rows]
bg_sql = ",".join("'{}'".format(b.replace("'", "''")) for b in bg_ids)

COPIES = [
    ("copros", f"row_id IN ({ids_sql})"),
    ("liens", f"row_id IN ({ids_sql})"),
    ("batiments", f"batiment_groupe_id IN ({bg_sql})"),
    ("dpe_logements", f"batiment_groupe_id IN ({bg_sql})"),
    ("conso_dle", f"batiment_groupe_id IN ({bg_sql})"),
    ("icu_copros", f"row_id IN ({ids_sql})"),
    ("prioritaires", f"row_id IN ({ids_sql})"),
    ("plan_actions", f"row_id IN ({ids_sql})"),
    ("scenarios_copro", f"row_id IN ({ids_sql})"),
    ("hypotheses", "1=1"),
    ("actions_catalogue", "1=1"),
]
for table, where in COPIES:
    cols = [c[1] for c in dst.execute(f"PRAGMA table_info({table})").fetchall()]
    cols_sql = ", ".join(cols)
    dst.execute(f"INSERT INTO {table} ({cols_sql}) SELECT {cols_sql} FROM src.{table} WHERE {where}")
    n = dst.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    print(f"  {table}: {n} lignes")
dst.commit()
dst.close()
con.close()
print("Base filtree construite :", FILTERED_DB)

# ---------------- 3) rendu HTML statique (anglais uniquement) ----------------
import db  # noqa: E402  (import tardif : depend de sys.path deja configure)
import i18n  # noqa: E402
from jinja2 import Environment, FileSystemLoader  # noqa: E402

db.DB_PATH = FILTERED_DB  # bascule db.py sur la base filtree pour toute la generation

LANG = "en"
ENERGIES = ["gaz", "electricite", "reseau de chaleur", "fioul", "gpl/butane/propane"]


def action_champ(a, champ):
    code = a.get("code") or a.get("action_code")
    v = i18n.ACTIONS_EN.get(code, {}).get(champ)
    return v if v else a.get(champ)


def contexte(**kwargs):
    base = {
        "lang": LANG, "root": "", "n_demo": N_CIBLE,
        "t": lambda cle, **kw: i18n.t(LANG, cle, **kw),
        "statut_label": lambda code: i18n.STATUT_LABELS.get(code, {}).get(LANG, code),
        "energie_label": lambda val: i18n.ENERGIE_LABELS.get(val, {}).get(LANG, val),
        "match_label": lambda val: i18n.MATCH_LABELS.get(val, {}).get(LANG, val),
        "famille_label": lambda val: i18n.FAMILLE_LABELS.get(val, {}).get(LANG, val),
        "usage_label": lambda val: i18n.USAGE_LABELS.get(val, {}).get(LANG, val),
        "unite_cout_label": lambda val: i18n.traduire_unite_cout(val, LANG),
        "hyp_groupe_titre": lambda titre: i18n.HYP_GROUPES_EN.get(titre, titre),
        "hyp_label": lambda cle: i18n.hyp_label(cle, LANG),
        "action_nom": lambda a: action_champ(a, "nom"),
        "action_eligibilite": lambda a: action_champ(a, "eligibilite"),
        "scenario_nom": lambda nom: i18n.SCENARIO_NOM_EN.get(nom, nom),
        "traduire_arg": lambda texte: i18n.argumentaire(texte, LANG),
    }
    base.update(kwargs)
    return base


env = Environment(loader=FileSystemLoader(os.path.join(BASE, "templates_static")))

if os.path.exists(OUT):
    shutil.rmtree(OUT)
os.makedirs(os.path.join(OUT, "properties"))
os.makedirs(os.path.join(OUT, "static"))
shutil.copy(os.path.join(BASE, "static", "style.css"), os.path.join(OUT, "static", "style.css"))

# ---- dashboard (index.html) ----
stats = db.stats_parc()
ordre = ["A", "B", "C", "D", "E", "F", "G", "NC"]
dpe = [(c, stats["repartition_dpe"].get(c, 0)) for c in ordre
       if c != "NC" or stats["repartition_dpe"].get("NC", 0)]
max_dpe = max((v for _, v in dpe), default=1) or 1
energies_rep = list(stats["repartition_energie"].items())[:6]
max_en = max((v for _, v in energies_rep), default=1) or 1
html = env.get_template("dashboard.html").render(**contexte(
    s=stats, dpe=dpe, max_dpe=max_dpe, energies=energies_rep, max_en=max_en,
    statuts=stats["repartition_statuts"]))
with open(os.path.join(OUT, "index.html"), "w", encoding="utf-8") as f:
    f.write(html)
print("index.html genere")

# ---- properties.html ----
res = db.chercher_copros(tri="score", limite=200, page=1)
rows = res["resultats"]
for r in rows:
    r["slug"] = re.sub(r"[^a-zA-Z0-9]+", "-", str(r["ref"])).strip("-")
html = env.get_template("copros.html").render(**contexte(
    rows=rows, total=res["total"], energies=ENERGIES, statuts=db.STATUTS))
with open(os.path.join(OUT, "properties.html"), "w", encoding="utf-8") as f:
    f.write(html)
print(f"properties.html genere ({len(rows)} lignes)")

# ---- gestes.html ----
cat = db.catalogue_decarbonation()
html = env.get_template("gestes.html").render(**contexte(**cat))
with open(os.path.join(OUT, "gestes.html"), "w", encoding="utf-8") as f:
    f.write(html)
print("gestes.html genere")

# ---- fiche/<slug>.html x 50 ----
n_ok = 0
for r in rows:
    c = db.fiche_copro(r["ref"])
    if c is None:
        continue
    html = env.get_template("fiche.html").render(**contexte(
        root="../", c=c, msg="", statuts=db.STATUTS))
    with open(os.path.join(OUT, "properties", f"{r['slug']}.html"), "w", encoding="utf-8") as f:
        f.write(html)
    n_ok += 1
print(f"{n_ok} fiches individuelles generees dans properties/")

os.remove(FILTERED_DB)
print("Termine. Demo statique dans :", OUT)
