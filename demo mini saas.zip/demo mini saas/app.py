# -*- coding: utf-8 -*-
"""Mini-SaaS Parc Immo — app web + API REST (FastAPI).

Lancement : python -m uvicorn app:app --port 8000  (ou lancer.bat)
Interface : http://localhost:8000 · API documentée : http://localhost:8000/docs
Jeton d'accès : variable d'environnement PARCIMMO_TOKEN (défaut : demo-parcimmo).
"""
import io
import os

import pandas as pd
from fastapi import FastAPI, Request, Form, UploadFile, File, Body
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

import db
import i18n

BASE = os.path.dirname(os.path.abspath(__file__))
TOKEN = os.environ.get("PARCIMMO_TOKEN", "demo-parcimmo")

app = FastAPI(title="Parc Immo — démonstrateur Eneville", version="0.1",
              description="Gestion du parc de copropriétés de Parc Immo (bailleur social fictif) : "
                          "données BDNB/RNC/DVF/ICU, couche gestion éditable et journalisée, "
                          "imports utilisateurs.")
app.mount("/static", StaticFiles(directory=os.path.join(BASE, "static")), name="static")
tpl = Jinja2Templates(directory=os.path.join(BASE, "templates"))


def get_lang(request: Request) -> str:
    lang = request.cookies.get("lang", "fr")
    return lang if lang in i18n.LANGUES else "fr"


def ctx(request: Request, **kwargs):
    """Contexte de rendu commun : requete + langue + fonctions de traduction."""
    lang = get_lang(request)

    def action_champ(a, champ):
        if lang == "en":
            code = a.get("code") or a.get("action_code")
            v = i18n.ACTIONS_EN.get(code, {}).get(champ)
            if v:
                return v
        return a.get(champ)

    base = {"request": request, "lang": lang, "t": lambda cle, **kw: i18n.t(lang, cle, **kw),
            "statut_label": lambda code: i18n.STATUT_LABELS.get(code, {}).get(lang, code),
            "energie_label": lambda val: i18n.ENERGIE_LABELS.get(val, {}).get(lang, val),
            "match_label": lambda val: i18n.MATCH_LABELS.get(val, {}).get(lang, val),
            "famille_label": lambda val: i18n.FAMILLE_LABELS.get(val, {}).get(lang, val),
            "usage_label": lambda val: i18n.USAGE_LABELS.get(val, {}).get(lang, val),
            "unite_cout_label": lambda val: i18n.traduire_unite_cout(val, lang),
            "hyp_groupe_titre": lambda titre: i18n.HYP_GROUPES_EN.get(titre, titre) if lang == "en" else titre,
            "hyp_label": lambda cle: i18n.hyp_label(cle, lang),
            "action_nom": lambda a: action_champ(a, "nom"),
            "action_eligibilite": lambda a: action_champ(a, "eligibilite"),
            "scenario_nom": lambda nom: i18n.SCENARIO_NOM_EN.get(nom, nom) if lang == "en" else nom,
            "traduire_arg": lambda texte: i18n.argumentaire(texte, lang)}
    base.update(kwargs)
    return base


@app.get("/lang/{code}")
def changer_langue(request: Request, code: str):
    suivant = request.headers.get("referer") or "/"
    resp = RedirectResponse(suivant, status_code=302)
    if code in i18n.LANGUES:
        resp.set_cookie("lang", code, max_age=365 * 24 * 3600)
    return resp

DEPS = ["75", "77", "78", "91", "92", "93", "94", "95", "13", "42", "44", "58", "60", "63", "76"]
ENERGIES = ["gaz", "electricite", "reseau de chaleur", "fioul", "gpl/butane/propane"]


def autorise(request: Request):
    return request.cookies.get("token") == TOKEN


def garde(request: Request):
    if not autorise(request):
        return RedirectResponse("/login", status_code=302)
    return None


# ---------------- auth minimale ----------------
@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request, erreur: str = ""):
    return tpl.TemplateResponse(request, "login.html", ctx(request, erreur=erreur))


@app.post("/login")
def login(request: Request, token: str = Form(...)):
    if token != TOKEN:
        lang = get_lang(request)
        return tpl.TemplateResponse(request, "login.html",
                                    ctx(request, erreur=i18n.t(lang, "login_jeton_invalide")))
    resp = RedirectResponse("/", status_code=302)
    resp.set_cookie("token", token, httponly=True)
    return resp


# ---------------- pages ----------------
@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    if (r := garde(request)):
        return r
    stats = db.stats_parc()
    ordre = ["A", "B", "C", "D", "E", "F", "G", "NC"]
    dpe = [(c, stats["repartition_dpe"].get(c, 0)) for c in ordre
           if c != "NC" or stats["repartition_dpe"].get("NC", 0)]
    max_dpe = max(v for _, v in dpe) or 1
    energies = list(stats["repartition_energie"].items())[:6]
    max_en = max(v for _, v in energies) or 1
    return tpl.TemplateResponse(request, "dashboard.html", ctx(
        request, s=stats, dpe=dpe, max_dpe=max_dpe,
        energies=energies, max_en=max_en, statuts=stats["repartition_statuts"]))


@app.get("/copros", response_class=HTMLResponse)
def liste_copros(request: Request, q: str = "", dep: str = "", dpe: str = "", energie: str = "",
                 focus: str = "", icu: str = "", argile: str = "", statut: str = "",
                 tri: str = "score", page: int = 1):
    if (r := garde(request)):
        return r
    res = db.chercher_copros(
        recherche=q or None, dep=dep or None, classe_dpe=dpe or None, energie=energie or None,
        tantiemes_min=0.5 if focus else None, expo_icu=icu or None, expo_argile=argile or None,
        statut=statut or None, tri=tri, limite=100, page=page)
    from urllib.parse import urlencode
    filtres = {k: v for k, v in [("q", q), ("dep", dep), ("dpe", dpe), ("energie", energie),
                                 ("focus", focus), ("icu", icu), ("argile", argile),
                                 ("statut", statut), ("tri", tri)] if v}
    debut = (res["page"] - 1) * res["limite"] + 1 if res["total"] else 0
    fin = min(res["page"] * res["limite"], res["total"])
    return tpl.TemplateResponse(request, "copros.html", ctx(
        request, rows=res["resultats"], total=res["total"],
        page=res["page"], debut=debut, fin=fin,
        a_suivant=fin < res["total"], qs=urlencode(filtres),
        q=q, dep=dep, dpe=dpe, energie=energie,
        focus=focus, icu=icu, argile=argile, statut=statut, tri=tri,
        deps=DEPS, energies=ENERGIES, statuts=db.STATUTS))


@app.get("/copros/{row_id}", response_class=HTMLResponse)
def fiche(request: Request, row_id: int, msg: str = ""):
    if (r := garde(request)):
        return r
    c = db.fiche_copro(row_id)
    if c is None:
        return HTMLResponse("Copro introuvable", status_code=404)
    return tpl.TemplateResponse(request, "fiche.html", ctx(request, c=c, msg=msg, statuts=db.STATUTS))


@app.post("/copros/{row_id}/gestion")
def maj_gestion_web(request: Request, row_id: int, statut: str = Form(""), note: str = Form(""),
                    contact_syndic: str = Form(""), tantiemes_bailleur: str = Form("")):
    if (r := garde(request)):
        return r
    for champ, val in [("statut", statut), ("note", note), ("contact_syndic", contact_syndic),
                       ("tantiemes_bailleur", tantiemes_bailleur)]:
        if val != "":
            db.maj_gestion(row_id, champ,
                           float(val) if champ == "tantiemes_bailleur" else val, source="web")
    msg = i18n.t(get_lang(request), "fiche_enregistre_msg")
    return RedirectResponse(f"/copros/{row_id}?msg={msg}", status_code=302)


@app.get("/gestes", response_class=HTMLResponse)
def gestes(request: Request):
    if (r := garde(request)):
        return r
    cat = db.catalogue_decarbonation()
    return tpl.TemplateResponse(request, "gestes.html", ctx(request, **cat))


@app.get("/import", response_class=HTMLResponse)
def import_page(request: Request):
    if (r := garde(request)):
        return r
    con = db.connect()
    historique = [dict(x) for x in con.execute(
        "SELECT * FROM imports ORDER BY ts DESC LIMIT 15").fetchall()]
    con.close()
    return tpl.TemplateResponse(request, "import.html", ctx(request, historique=historique, resultat=None))


@app.post("/import", response_class=HTMLResponse)
async def import_post(request: Request, fichier: UploadFile = File(...)):
    if (r := garde(request)):
        return r
    contenu = await fichier.read()
    try:
        if fichier.filename.lower().endswith((".xlsx", ".xls")):
            df = pd.read_excel(io.BytesIO(contenu))
        else:
            df = pd.read_csv(io.BytesIO(contenu), sep=None, engine="python", encoding="utf-8-sig")
        resultat = db.importer_dataframe(df, fichier.filename, source="web")
    except Exception as e:
        lecture = "Lecture impossible" if get_lang(request) != "en" else "Could not read file"
        resultat = {"ok": False, "erreur": f"{lecture} : {e}"}
    con = db.connect()
    historique = [dict(x) for x in con.execute(
        "SELECT * FROM imports ORDER BY ts DESC LIMIT 15").fetchall()]
    con.close()
    return tpl.TemplateResponse(request, "import.html", ctx(request, historique=historique, resultat=resultat))


# ---------------- API JSON (documentée sur /docs) ----------------
def api_garde(request: Request):
    if request.cookies.get("token") == TOKEN or request.headers.get("x-token") == TOKEN:
        return None
    return JSONResponse({"erreur": "jeton manquant (cookie ou en-tête X-Token)"}, status_code=401)


@app.get("/api/kpis")
def api_kpis(request: Request):
    return api_garde(request) or db.stats_parc()


@app.get("/api/copros")
def api_copros(request: Request, q: str = None, dep: str = None, dpe: str = None,
               energie: str = None, tantiemes_min: float = None, icu: str = None,
               argile: str = None, statut: str = None, tri: str = "score",
               limite: int = 50, page: int = 1):
    return api_garde(request) or db.chercher_copros(
        recherche=q, dep=dep, classe_dpe=dpe, energie=energie, tantiemes_min=tantiemes_min,
        expo_icu=icu, expo_argile=argile, statut=statut, tri=tri, limite=limite, page=page)


@app.get("/api/copros/{ref}")
def api_fiche(request: Request, ref: str):
    if (r := api_garde(request)):
        return r
    c = db.fiche_copro(ref)
    return c if c else JSONResponse({"erreur": "introuvable"}, status_code=404)


@app.patch("/api/gestion/{ref}")
def api_maj(request: Request, ref: str, corps: dict = Body(...)):
    if (r := api_garde(request)):
        return r
    return db.maj_gestion(ref, corps.get("champ"), corps.get("valeur"),
                          corps.get("motif"), source="api")


@app.post("/api/import")
async def api_import(request: Request, fichier: UploadFile = File(...)):
    if (r := api_garde(request)):
        return r
    contenu = await fichier.read()
    if fichier.filename.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(io.BytesIO(contenu))
    else:
        df = pd.read_csv(io.BytesIO(contenu), sep=None, engine="python", encoding="utf-8-sig")
    return db.importer_dataframe(df, fichier.filename, source="api")
