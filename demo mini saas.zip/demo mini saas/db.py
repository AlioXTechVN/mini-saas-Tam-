# -*- coding: utf-8 -*-
"""Coeur partage du mini-SaaS Parc Immo : acces SQLite, mises a jour journalisees, imports.

Utilise par app.py (web/API) et mcp_server.py (Claude Code / VS Code).
Regle : les donnees BDNB sont en LECTURE SEULE ; s'editent uniquement la couche gestion
(statut, note, contact syndic) et quelques champs copro (tantiemes_bailleur, nb_logt),
le tout trace dans audit_log.
"""
import json
import os
import sqlite3
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE, "data", "parc.db")

STATUTS = ["nouveau", "a_etudier", "audit_lance", "travaux_votes", "travaux_en_cours", "termine"]
CHAMPS_GESTION = {"statut", "note", "contact_syndic"}
CHAMPS_COPRO_EDITABLES = {"tantiemes_bailleur", "nb_logt"}


def connect():
    con = sqlite3.connect(DB_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con


def log(con, source, table_cible, cle, champ, ancienne, nouvelle, motif=None, acteur=None):
    con.execute(
        "INSERT INTO audit_log (ts, source, acteur, table_cible, cle, champ, ancienne_valeur,"
        " nouvelle_valeur, motif) VALUES (?,?,?,?,?,?,?,?,?)",
        (datetime.now().isoformat(timespec="seconds"), source, acteur, table_cible,
         str(cle), champ, None if ancienne is None else str(ancienne),
         None if nouvelle is None else str(nouvelle), motif))


def resoudre_row_id(con, ref):
    """Accepte un row_id entier ou une ref Parc Immo ('1330.1'). Retourne row_id ou None."""
    try:
        rid = int(ref)
        if con.execute("SELECT 1 FROM copros WHERE row_id=?", (rid,)).fetchone():
            return rid
    except (ValueError, TypeError):
        pass
    r = con.execute("SELECT row_id FROM copros WHERE CAST(ref AS TEXT)=? OR ref=?",
                    (str(ref), ref)).fetchone()
    return r["row_id"] if r else None


def maj_gestion(ref, champ, valeur, motif=None, source="web", acteur=None):
    """Met a jour un champ editable (gestion ou copro), avec journalisation."""
    con = connect()
    try:
        rid = resoudre_row_id(con, ref)
        if rid is None:
            return {"ok": False, "erreur": f"Copro introuvable : {ref}"}
        if champ in CHAMPS_GESTION:
            if champ == "statut" and valeur not in STATUTS:
                return {"ok": False, "erreur": f"Statut invalide. Choix : {', '.join(STATUTS)}"}
            con.execute("INSERT OR IGNORE INTO gestion (row_id) VALUES (?)", (rid,))
            old = con.execute(f"SELECT {champ} FROM gestion WHERE row_id=?", (rid,)).fetchone()[champ]
            con.execute(f"UPDATE gestion SET {champ}=?, maj_le=?, maj_par=? WHERE row_id=?",
                        (valeur, datetime.now().isoformat(timespec="seconds"), acteur or source, rid))
            log(con, source, "gestion", rid, champ, old, valeur, motif, acteur)
        elif champ in CHAMPS_COPRO_EDITABLES:
            old = con.execute(f"SELECT {champ} FROM copros WHERE row_id=?", (rid,)).fetchone()[champ]
            con.execute(f"UPDATE copros SET {champ}=? WHERE row_id=?", (valeur, rid))
            log(con, source, "copros", rid, champ, old, valeur, motif, acteur)
            con.commit()
            recalculer_priorites()  # le score depend des tantiemes et de la taille
        else:
            autorises = sorted(CHAMPS_GESTION | CHAMPS_COPRO_EDITABLES)
            return {"ok": False, "erreur": f"Champ non éditable : {champ}. Autorisés : {', '.join(autorises)} "
                    "(les données BDNB sont en lecture seule)."}
        con.commit()
        return {"ok": True, "row_id": rid, "champ": champ, "valeur": valeur}
    finally:
        con.close()


def importer_dataframe(df, nom_fichier, source="web", acteur=None):
    """Importe un DataFrame utilisateur. Exige une colonne 'ref' (ou 'row_id').

    - Les colonnes de la liste blanche (tantiemes_bailleur, nb_logt, statut, note, contact_syndic)
      mettent a jour directement copros/gestion (journalise).
    - Toutes les autres colonnes sont stockees dans donnees_importees (provenance conservee).
    """
    import pandas as pd
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    cle = "ref" if "ref" in df.columns else ("row_id" if "row_id" in df.columns else None)
    if cle is None:
        return {"ok": False, "erreur": "Le fichier doit contenir une colonne 'ref' ou 'row_id'."}
    con = connect()
    try:
        cur = con.execute(
            "INSERT INTO imports (ts, fichier, source, acteur, nb_lignes) VALUES (?,?,?,?,?)",
            (datetime.now().isoformat(timespec="seconds"), nom_fichier, source, acteur, len(df)))
        import_id = cur.lastrowid
        maj, stockees, inconnues = 0, 0, 0
        whitelist = CHAMPS_GESTION | CHAMPS_COPRO_EDITABLES
        for _, row in df.iterrows():
            rid = resoudre_row_id(con, row[cle])
            if rid is None:
                inconnues += 1
                continue
            for col in df.columns:
                if col == cle or pd.isna(row[col]):
                    continue
                val = row[col]
                if col in whitelist:
                    if col in CHAMPS_GESTION:
                        con.execute("INSERT OR IGNORE INTO gestion (row_id) VALUES (?)", (rid,))
                        old = con.execute(f"SELECT {col} FROM gestion WHERE row_id=?", (rid,)).fetchone()[col]
                        con.execute(f"UPDATE gestion SET {col}=?, maj_le=?, maj_par=? WHERE row_id=?",
                                    (str(val), datetime.now().isoformat(timespec="seconds"),
                                     acteur or source, rid))
                    else:
                        old = con.execute(f"SELECT {col} FROM copros WHERE row_id=?", (rid,)).fetchone()[col]
                        con.execute(f"UPDATE copros SET {col}=? WHERE row_id=?", (val, rid))
                    log(con, f"import:{import_id}", "copros/gestion", rid, col, old, val, nom_fichier, acteur)
                    maj += 1
                else:
                    con.execute(
                        "INSERT INTO donnees_importees (import_id, row_id, champ, valeur) VALUES (?,?,?,?)",
                        (import_id, rid, col, str(val)))
                    stockees += 1
        con.execute("UPDATE imports SET nb_maj=?, nb_stockees=?, nb_refs_inconnues=? WHERE id=?",
                    (maj, stockees, inconnues, import_id))
        con.commit()
        if maj and (CHAMPS_COPRO_EDITABLES & set(df.columns)):
            recalculer_priorites()
        return {"ok": True, "import_id": import_id, "lignes": len(df), "champs_maj": maj,
                "valeurs_stockees": stockees, "refs_inconnues": inconnues}
    finally:
        con.close()


def importer_fichier(chemin, source="mcp", acteur=None):
    import pandas as pd
    if not os.path.exists(chemin):
        return {"ok": False, "erreur": f"Fichier introuvable : {chemin}"}
    if chemin.lower().endswith((".xlsx", ".xls")):
        df = pd.read_excel(chemin)
    else:
        df = pd.read_csv(chemin, sep=None, engine="python", encoding="utf-8-sig")
    return importer_dataframe(df, os.path.basename(chemin), source, acteur)


def recalculer_priorites():
    """Recalcule le score de priorité pour TOUTES les copros (table prioritaires).

    Formule (mise à jour 2026-07-19, demande du client) — composante DPE avec le DPE immeuble
    (réel ou estimé M3) pondéré PLUS FORT que le pire DPE des bâtiments :
      0,7 × points(DPE immeuble) + 0,3 × points(pire DPE)   [pire DPE seul si aucun DPE immeuble]
      (G=5 F=4 E=3 D=2 C=1 B/A=0, inconnu=1)
      + énergie dominante (fioul/GPL=3, gaz=2, élec=1, réseau=0, inconnue=1)
      + taille (logts Parc Immo / 50, plafonné à 2) + tantièmes Parc Immo (0-1).
    Relancé automatiquement quand tantiemes_bailleur ou nb_logt changent (maj ou import).
    """
    DPE_PTS = {"G": 5, "F": 4, "E": 3, "D": 2, "C": 1, "B": 0, "A": 0}
    EN_PTS = {"fioul": 3, "gpl/butane/propane": 3, "gaz": 2, "electricite": 1,
              "reseau de chaleur": 0}
    con = connect()
    try:
        rows = con.execute("""
            SELECT c.row_id, c.ref, c.nb_logt, c.tantiemes_bailleur,
                   (SELECT MAX(b.classe_dpe) FROM liens l JOIN batiments b
                    ON b.batiment_groupe_id=l.batiment_groupe_id
                    WHERE l.row_id=c.row_id
                      AND b.classe_dpe IN ('A','B','C','D','E','F','G')) AS pire,
                   (SELECT MAX(COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee))
                    FROM liens l JOIN batiments b
                    ON b.batiment_groupe_id=l.batiment_groupe_id
                    WHERE l.row_id=c.row_id
                      AND COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee)
                          IN ('A','B','C','D','E','F','G')) AS dpe_imm,
                   (SELECT COALESCE(b.energie_chauffage, b.energie_estimee)
                    FROM liens l JOIN batiments b
                    ON b.batiment_groupe_id=l.batiment_groupe_id
                    WHERE l.row_id=c.row_id
                      AND COALESCE(b.energie_chauffage, b.energie_estimee) IS NOT NULL
                    GROUP BY COALESCE(b.energie_chauffage, b.energie_estimee)
                    ORDER BY COUNT(*) DESC LIMIT 1) AS energie
            FROM copros c""").fetchall()
        con.execute("DELETE FROM prioritaires")
        for r in rows:
            try:
                taille = min(2.0, float(r["nb_logt"] or 0) / 50.0)
            except (TypeError, ValueError):
                taille = 0.0
            pts_pire = DPE_PTS.get(r["pire"], 1)
            if r["dpe_imm"]:
                dpe_term = 0.7 * DPE_PTS.get(r["dpe_imm"], 1) + 0.3 * pts_pire
            else:
                dpe_term = pts_pire
            score = (dpe_term + EN_PTS.get(r["energie"], 1)
                     + taille + float(r["tantiemes_bailleur"] or 0))
            con.execute("INSERT INTO prioritaires (row_id, ref, score, pire_dpe, energie)"
                        " VALUES (?,?,?,?,?)",
                        (r["row_id"], r["ref"], round(score, 2), r["pire"], r["energie"]))
        con.commit()
        return len(rows)
    finally:
        con.close()


# ---------------- requetes de lecture ----------------

def stats_parc():
    con = connect()
    try:
        q1 = lambda sql: con.execute(sql).fetchone()[0]
        stats = {
            "copropriétés": q1("SELECT COUNT(*) FROM copros"),
            "bâtiments": q1("SELECT COUNT(*) FROM batiments"),
            "logements_bailleur": q1("SELECT CAST(SUM(nb_logt) AS INT) FROM copros"),
            "copros_focus_tantiemes_50": q1("SELECT COUNT(*) FROM copros WHERE tantiemes_bailleur>=0.5"),
            # statistiques DPE/energie sur les valeurs AFFICHEES dans l'app :
            # DPE immeuble reel, sinon estime (M3 ou IA) ; energie reelle, sinon estimee IA
            "batiments_avec_dpe": q1("SELECT COUNT(*) FROM batiments WHERE COALESCE(classe_dpe_immeuble, classe_dpe_estimee) IS NOT NULL"),
            "batiments_EFG": q1("SELECT COUNT(*) FROM batiments WHERE COALESCE(classe_dpe_immeuble, classe_dpe_estimee) IN ('E','F','G')"),
            "passoires_FG": q1("SELECT COUNT(*) FROM batiments WHERE COALESCE(classe_dpe_immeuble, classe_dpe_estimee) IN ('F','G')"),
            "batiments_risque_passoire": q1("SELECT COUNT(*) FROM batiments WHERE risque_passoire=1"),
            "batiments_fioul": q1("SELECT COUNT(*) FROM batiments WHERE COALESCE(energie_chauffage, energie_estimee)='fioul'"),
            "batiments_energie_estimee": q1("SELECT COUNT(*) FROM batiments WHERE energie_chauffage IS NULL AND energie_estimee IS NOT NULL"),
            "batiments_icu_forte": q1("SELECT COUNT(*) FROM batiments WHERE expo_icu='Forte'"),
            "batiments_argile_fort": q1("SELECT COUNT(*) FROM batiments WHERE alea_argile='Fort'"),
            "copros_argile_fort": q1("SELECT COUNT(DISTINCT row_id) FROM liens l JOIN batiments b USING(batiment_groupe_id) WHERE b.alea_argile='Fort'"),
            "copros_avec_immat_rnc": q1("SELECT COUNT(DISTINCT row_id) FROM liens l JOIN batiments b USING(batiment_groupe_id) WHERE b.rnc_immat_finale IS NOT NULL"),
            "repartition_dpe": dict(con.execute(
                "SELECT COALESCE(COALESCE(classe_dpe_immeuble, classe_dpe_estimee),'NC'), COUNT(*)"
                " FROM batiments GROUP BY 1 ORDER BY 1").fetchall()),
            "repartition_energie": dict(con.execute(
                "SELECT COALESCE(COALESCE(energie_chauffage, energie_estimee),'non connu'), COUNT(*)"
                " FROM batiments GROUP BY 1 ORDER BY 2 DESC").fetchall()),
            "sources_dpe": dict(con.execute(
                "SELECT CASE WHEN classe_dpe_immeuble IS NOT NULL THEN 'DPE immeuble'"
                " WHEN source_dpe LIKE 'DPE estimé par l''IA%' THEN 'estimé par IA'"
                " WHEN classe_dpe_estimee IS NOT NULL THEN 'estimé DPE logements (M3)'"
                " ELSE 'aucun' END, COUNT(*) FROM batiments GROUP BY 1").fetchall()),
            "repartition_statuts": dict(con.execute(
                "SELECT COALESCE(g.statut,'nouveau'), COUNT(*) FROM copros c LEFT JOIN gestion g USING(row_id) GROUP BY 1").fetchall()),
        }
        # ---- estimation carbone v1 : 100 % du parc
        # batiments documentes : intensite GES du DPE representatif x surface habitable DPE.
        # batiments non documentes : intensite = mediane GES de leur classe DPE affichee
        # (reelle ou estimee, medianes rendues monotones A->G) ; surface = nb logements x
        # ratio m2/logt median du parc documente, sinon emprise x niveaux x 0,65 (part
        # habitable), sinon surface mediane du parc.
        import statistics
        doc = con.execute(
            "SELECT ges_m2, dpe_mix_arrete_surface_habitable_immeuble AS surf FROM batiments"
            " WHERE ges_m2 IS NOT NULL AND dpe_mix_arrete_surface_habitable_immeuble > 0").fetchall()
        ges_c = [r[0] for r in con.execute(
            "SELECT ges_m2 FROM batiments WHERE classe_dpe='C' AND ges_m2 IS NOT NULL").fetchall()]
        if doc and ges_c:
            med_c = statistics.median(ges_c)
            # medianes GES par classe affichee (documentes), monotones de A a G
            med_cl, plancher = {}, 0.0
            for cl in "ABCDEFG":
                vals = [r[0] for r in con.execute(
                    "SELECT ges_m2 FROM batiments WHERE ges_m2 IS NOT NULL"
                    " AND COALESCE(classe_dpe_immeuble, classe_dpe_estimee)=?", (cl,))]
                plancher = max(plancher, statistics.median(vals)) if vals else plancher
                med_cl[cl] = plancher
            ratios = [r["s"] / r["n"] for r in con.execute(
                "SELECT dpe_mix_arrete_surface_habitable_immeuble s, nb_logements_bat n"
                " FROM batiments WHERE dpe_mix_arrete_surface_habitable_immeuble > 0"
                " AND nb_logements_bat > 0")]
            m2_par_logt = statistics.median(ratios) if ratios else 60.0
            surf_med = statistics.median([r["surf"] for r in doc])
            co2_doc = sum(r["ges_m2"] * r["surf"] for r in doc) / 1000.0       # tCO2e/an
            pot = sum(max(0.0, (r["ges_m2"] - med_c)) * r["surf"] for r in doc) / 1000.0
            co2_est, n_est = 0.0, 0
            for r in con.execute("""
                SELECT COALESCE(classe_dpe_immeuble, classe_dpe_estimee) cl,
                       nb_logements_bat nl, s_geom_groupe emp, ffo_bat_nb_niveau niv
                FROM batiments
                WHERE (ges_m2 IS NULL OR dpe_mix_arrete_surface_habitable_immeuble IS NULL
                       OR dpe_mix_arrete_surface_habitable_immeuble <= 0)
                  AND COALESCE(classe_dpe_immeuble, classe_dpe_estimee) IS NOT NULL"""):
                if r["nl"] and r["nl"] > 0:
                    surf = r["nl"] * m2_par_logt
                elif r["emp"] and r["niv"] and r["emp"] > 0 and r["niv"] > 0:
                    surf = r["emp"] * r["niv"] * 0.65
                else:
                    surf = surf_med
                intens = med_cl.get(r["cl"], med_c)
                co2_est += intens * surf / 1000.0
                pot += max(0.0, intens - med_c) * surf / 1000.0
                n_est += 1
            co2 = co2_doc + co2_est
            stats["co2_tan"] = round(co2)
            stats["co2_potentiel_tan"] = round(pot)
            stats["co2_pct_reduction"] = round(pot / co2 * 100) if co2 else 0
            stats["co2_nb_bat"] = len(doc)
            stats["co2_nb_bat_est"] = n_est
            stats["co2_pct_parc"] = round((len(doc) + n_est) / max(1, stats["bâtiments"]) * 100)
            stats["co2_part_estimee_pct"] = round(co2_est / co2 * 100) if co2 else 0
            stats["co2_ref_c"] = round(med_c)
        # plan de decarbonation (migration_006) : potentiel des scenarios S3 du focus
        try:
            r = con.execute("SELECT COUNT(*), SUM(reduc_tco2_an), SUM(reste_a_charge)"
                            " FROM scenarios_copro WHERE scenario='S3'").fetchone()
            if r and r[0]:
                stats["decarb_copros_chiffrees"] = r[0]
                stats["decarb_s3_tco2"] = round(r[1])
                stats["decarb_s3_rac"] = round(r[2])
            # focus tantiemes Parc Immo >= 50 % : potentiel du plan v1 (scenario Renovation
            # globale = S3, la cible la plus ambitieuse) pour les copros majoritaires Parc Immo
            f = con.execute("""
                SELECT COUNT(*), SUM(s.cout_total), SUM(s.reste_a_charge),
                       SUM(s.econ_kwh_an), SUM(s.econ_eur_an), SUM(s.reduc_tco2_an),
                       SUM(s.quote_part_bailleur), SUM(s.valeur_verte_eur),
                       SUM(c.tantiemes_bailleur * s.econ_eur_an),
                       SUM(c.tantiemes_bailleur * s.valeur_verte_eur)
                FROM scenarios_copro s JOIN copros c USING(row_id)
                WHERE s.scenario='S3' AND c.tantiemes_bailleur >= 0.5""").fetchone()
            if f and f[0]:
                stats["focus50_nb_copros"] = f[0]
                stats["focus50_cout_total"] = round(f[1])
                stats["focus50_rac_total"] = round(f[2])
                stats["focus50_kwh_an"] = round(f[3])
                stats["focus50_eur_an"] = round(f[4])
                stats["focus50_tco2_an"] = round(f[5])
                stats["focus50_roi"] = round(f[2] / f[4], 1) if f[4] else None
                # part du reste a charge portee par Parc Immo (physique CO2/kWh non
                # proratisee : ce sont des grandeurs du batiment entier, pas de la
                # propriete de Parc Immo seule — cf. reponse a l'utilisateur)
                stats["focus50_quote_part"] = round(f[6])
                stats["focus50_financements"] = round(f[1] - f[2])   # CEE + MPR obtenus
                stats["focus50_vv_total"] = round(f[7])              # valeur verte, tout le parc
                # quote-part Parc Immo de la valeur verte et des economies annuelles :
                # approximation au prorata des tantiemes (comme pour le reste a charge)
                stats["focus50_eur_an_bailleur"] = round(f[8])
                stats["focus50_vv_bailleur"] = round(f[9])
                rac_net_bailleur = max(0.0, f[6] - f[9])
                stats["focus50_roi_vv_bailleur"] = round(rac_net_bailleur / f[8], 1) if f[8] else None
        except sqlite3.OperationalError:
            pass
        return stats
    finally:
        con.close()


def chercher_copros(recherche=None, dep=None, classe_dpe=None, energie=None,
                    tantiemes_min=None, expo_icu=None, expo_argile=None, statut=None,
                    tri="score", limite=50, page=1):
    """Retourne {"total": n, "page": p, "limite": l, "resultats": [...]}."""
    con = connect()
    try:
        base_from = """
        FROM copros c
        LEFT JOIN gestion g USING(row_id)
        LEFT JOIN prioritaires p USING(row_id)
        LEFT JOIN icu_copros ic USING(row_id)"""
        where = " WHERE 1=1"
        params = []
        if recherche:
            where += " AND (c.nom_copro LIKE ? OR c.adresse LIKE ? OR c.ville LIKE ? OR CAST(c.ref AS TEXT) LIKE ?)"
            params += [f"%{recherche}%"] * 4
        if dep:
            where += " AND substr(c.cp5,1,2)=?"
            params.append(dep)
        if classe_dpe:
            # filtre sur la classe AFFICHEE en colonne DPE immeuble : pire batiment de la
            # copro, vrai DPE prioritaire a egalite (meme regle que le SELECT plus bas) —
            # sinon une copro filtree C peut afficher le G estime d'un autre batiment
            where += """ AND (SELECT COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee)
                FROM liens lf JOIN batiments b ON b.batiment_groupe_id=lf.batiment_groupe_id
                WHERE lf.row_id=c.row_id
                  AND COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee) IS NOT NULL
                ORDER BY COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee) DESC,
                         (b.classe_dpe_immeuble IS NOT NULL) DESC LIMIT 1) = ?"""
            params.append(classe_dpe)
        if energie:
            # filtre sur l'energie DOMINANTE affichee en colonne (reelle BDNB ou estimee IA),
            # meme regle que le SELECT — sinon une copro majoritairement gaz sortirait
            # dans le filtre fioul pour un seul batiment fioul
            where += """ AND (SELECT COALESCE(b.energie_chauffage, b.energie_estimee)
                FROM liens lf2 JOIN batiments b ON b.batiment_groupe_id=lf2.batiment_groupe_id
                WHERE lf2.row_id=c.row_id
                  AND COALESCE(b.energie_chauffage, b.energie_estimee) IS NOT NULL
                GROUP BY COALESCE(b.energie_chauffage, b.energie_estimee)
                ORDER BY COUNT(*) DESC LIMIT 1) = ?"""
            params.append(energie)
        if tantiemes_min is not None:
            where += " AND c.tantiemes_bailleur>=?"
            params.append(float(tantiemes_min))
        if expo_icu:
            # filtre sur le niveau AFFICHE (pire batiment de la copro), meme regle que le
            # badge Confort d'ete — sinon une copro affichee « Risque fort » sortirait
            # dans le filtre Moyenne pour un batiment secondaire
            niveaux = {"Forte": 3, "Moyenne": 2, "Modérée": 1}
            where += """ AND (SELECT MAX(CASE b.expo_icu WHEN 'Forte' THEN 3
                             WHEN 'Moyenne' THEN 2 WHEN 'Modérée' THEN 1 ELSE 0 END)
                FROM liens lf3 JOIN batiments b ON b.batiment_groupe_id=lf3.batiment_groupe_id
                WHERE lf3.row_id=c.row_id) = ?"""
            params.append(niveaux.get(expo_icu, 0))
        if expo_argile:
            # meme regle : filtre sur le niveau AFFICHE (pire batiment de la copro)
            niveaux_argile = {"Fort": 3, "Moyen": 2, "Faible": 1}
            where += """ AND (SELECT MAX(CASE b.alea_argile WHEN 'Fort' THEN 3
                             WHEN 'Moyen' THEN 2 WHEN 'Faible' THEN 1 ELSE 0 END)
                FROM liens lf4 JOIN batiments b ON b.batiment_groupe_id=lf4.batiment_groupe_id
                WHERE lf4.row_id=c.row_id) = ?"""
            params.append(niveaux_argile.get(expo_argile, 0))
        if statut:
            where += " AND COALESCE(g.statut,'nouveau')=?"
            params.append(statut)

        total = con.execute("SELECT COUNT(*)" + base_from + where, params).fetchone()[0]

        select = """
        SELECT c.row_id, c.ref, c.nom_copro, c.adresse, c.cp5, c.ville,
               c.tantiemes_bailleur, c.nb_logt, g.statut,
               p.score AS score_priorite,
               ic.score_icu_moyen, ic.nb_bat_forte,
               (SELECT COUNT(*) FROM liens l WHERE l.row_id=c.row_id) AS nb_bat,
               (SELECT MAX(b.classe_dpe)
                FROM liens l4 JOIN batiments b ON b.batiment_groupe_id=l4.batiment_groupe_id
                WHERE l4.row_id=c.row_id
                  AND b.classe_dpe IN ('A','B','C','D','E','F','G')) AS pire_dpe,
               (SELECT COALESCE(b.energie_chauffage, b.energie_estimee)
                FROM liens l5 JOIN batiments b ON b.batiment_groupe_id=l5.batiment_groupe_id
                WHERE l5.row_id=c.row_id
                  AND COALESCE(b.energie_chauffage, b.energie_estimee) IS NOT NULL
                GROUP BY COALESCE(b.energie_chauffage, b.energie_estimee)
                ORDER BY COUNT(*) DESC LIMIT 1) AS energie_princ,
               (SELECT MAX(b.energie_chauffage IS NOT NULL)
                FROM liens l10 JOIN batiments b ON b.batiment_groupe_id=l10.batiment_groupe_id
                WHERE l10.row_id=c.row_id) AS energie_reelle,
               (SELECT MIN(b.fiabilite_energie)
                FROM liens l11 JOIN batiments b ON b.batiment_groupe_id=l11.batiment_groupe_id
                WHERE l11.row_id=c.row_id AND b.fiabilite_energie IS NOT NULL) AS fiabilite_energie,
               (SELECT COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee)
                FROM liens l6 JOIN batiments b ON b.batiment_groupe_id=l6.batiment_groupe_id
                WHERE l6.row_id=c.row_id
                  AND COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee) IS NOT NULL
                ORDER BY COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee) DESC,
                         (b.classe_dpe_immeuble IS NOT NULL) DESC LIMIT 1) AS dpe_immeuble,
               (SELECT CASE WHEN b.classe_dpe_immeuble IS NOT NULL THEN 'DPE immeuble'
                            ELSE b.source_dpe END
                FROM liens l7 JOIN batiments b ON b.batiment_groupe_id=l7.batiment_groupe_id
                WHERE l7.row_id=c.row_id
                  AND COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee) IS NOT NULL
                ORDER BY COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee) DESC,
                         (b.classe_dpe_immeuble IS NOT NULL) DESC LIMIT 1) AS source_dpe,
               (SELECT b.fiabilite_dpe
                FROM liens l8 JOIN batiments b ON b.batiment_groupe_id=l8.batiment_groupe_id
                WHERE l8.row_id=c.row_id
                  AND COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee) IS NOT NULL
                ORDER BY COALESCE(b.classe_dpe_immeuble, b.classe_dpe_estimee) DESC,
                         (b.classe_dpe_immeuble IS NOT NULL) DESC LIMIT 1) AS fiabilite_dpe,
               (SELECT MAX(b.risque_passoire)
                FROM liens l9 JOIN batiments b ON b.batiment_groupe_id=l9.batiment_groupe_id
                WHERE l9.row_id=c.row_id) AS risque_passoire,
               (SELECT MAX(CASE b.expo_icu WHEN 'Forte' THEN 3 WHEN 'Moyenne' THEN 2
                           WHEN 'Modérée' THEN 1 ELSE 0 END)
                FROM liens l2 JOIN batiments b ON b.batiment_groupe_id=l2.batiment_groupe_id
                WHERE l2.row_id=c.row_id) AS expo_niveau,
               (SELECT MAX(CASE b.alea_argile WHEN 'Fort' THEN 3 WHEN 'Moyen' THEN 2
                           WHEN 'Faible' THEN 1 ELSE 0 END)
                FROM liens l12 JOIN batiments b ON b.batiment_groupe_id=l12.batiment_groupe_id
                WHERE l12.row_id=c.row_id) AS argile_niveau,
               (SELECT GROUP_CONCAT(DISTINCT b2.rnc_immat_finale)
                FROM liens l3 JOIN batiments b2 ON b2.batiment_groupe_id=l3.batiment_groupe_id
                WHERE l3.row_id=c.row_id AND b2.rnc_immat_finale IS NOT NULL) AS immats_rnc"""
        tris = {"score": "p.score DESC NULLS LAST", "icu": "ic.score_icu_moyen DESC NULLS LAST",
                "tantiemes": "c.tantiemes_bailleur DESC NULLS LAST", "ville": "c.ville, c.ref",
                "ref": "c.ref"}
        page = max(1, int(page or 1))
        limite = int(limite)
        sql = select + base_from + where + \
            f" ORDER BY {tris.get(tri, tris['score'])} LIMIT ? OFFSET ?"
        rows = [dict(r) for r in con.execute(sql, params + [limite, (page - 1) * limite]).fetchall()]
        return {"total": total, "page": page, "limite": limite, "resultats": rows}
    finally:
        con.close()


def fiche_copro(ref):
    con = connect()
    try:
        rid = resoudre_row_id(con, ref)
        if rid is None:
            return None
        copro = dict(con.execute(
            "SELECT c.*, g.statut, g.note, g.contact_syndic, g.maj_le, g.maj_par,"
            " p.score AS score_priorite, p.pire_dpe, ic.score_icu_moyen, ic.nb_bat_forte"
            " FROM copros c LEFT JOIN gestion g USING(row_id)"
            " LEFT JOIN prioritaires p USING(row_id) LEFT JOIN icu_copros ic USING(row_id)"
            " WHERE c.row_id=?", (rid,)).fetchone())
        copro["batiments"] = [dict(r) for r in con.execute(
            "SELECT b.*, l.qualite_match, l.methode, l.score_ban FROM liens l"
            " JOIN batiments b USING(batiment_groupe_id) WHERE l.row_id=? ORDER BY b.batiment_groupe_id",
            (rid,)).fetchall()]
        copro["donnees_importees"] = [dict(r) for r in con.execute(
            "SELECT d.champ, d.valeur, i.fichier, i.ts FROM donnees_importees d"
            " JOIN imports i ON i.id=d.import_id WHERE d.row_id=? ORDER BY i.ts DESC LIMIT 50",
            (rid,)).fetchall()]
        copro["historique"] = [dict(r) for r in con.execute(
            "SELECT ts, source, champ, ancienne_valeur, nouvelle_valeur, motif FROM audit_log"
            " WHERE cle=? ORDER BY ts DESC LIMIT 30", (str(rid),)).fetchall()]
        # plan de decarbonation (migration_006, v1 focus tantiemes >= 50 %)
        try:
            copro["scenarios"] = [dict(r) for r in con.execute(
                "SELECT * FROM scenarios_copro WHERE row_id=? ORDER BY scenario",
                (rid,)).fetchall()]
            copro["plan_actions"] = [dict(r) for r in con.execute("""
                SELECT p.scenario, p.action_code, a.nom, a.famille,
                       SUM(p.cout) AS cout, SUM(p.cee) AS cee,
                       SUM(p.econ_eur_an) AS econ_eur_an,
                       SUM(p.reduc_tco2_an) AS reduc_tco2_an,
                       MAX(p.alerte) AS alerte
                FROM plan_actions p JOIN actions_catalogue a ON a.code = p.action_code
                WHERE p.row_id=? GROUP BY p.scenario, p.action_code
                ORDER BY p.scenario, cout DESC""", (rid,)).fetchall()]
        except sqlite3.OperationalError:
            copro["scenarios"], copro["plan_actions"] = [], []
        return copro
    finally:
        con.close()


def catalogue_decarbonation():
    """Référentiel des gestes de décarbonation : catalogue d'actions (coûts, financements,
    fourchettes de gain, éligibilité, sources) + fourchettes de ROI OBSERVÉES sur les
    calculs réels du parc + hypothèses globales groupées. Alimente la page /gestes."""
    import statistics
    con = connect()
    try:
        actions = [dict(r) for r in con.execute(
            "SELECT * FROM actions_catalogue ORDER BY famille, cout_bas").fetchall()]
        # ROI simple observé par action (retour = (coût - CEE) / économies annuelles),
        # calculé sur les lignes réelles du plan pour donner une fourchette honnête
        pay = {}
        for r in con.execute("""SELECT action_code, cout, cee, econ_eur_an
                                FROM plan_actions WHERE econ_eur_an > 0""").fetchall():
            pay.setdefault(r["action_code"], []).append(
                max(0.0, (r["cout"] - r["cee"])) / r["econ_eur_an"])
        for a in actions:
            v = sorted(pay.get(a["code"], []))
            a["nb_applications"] = len(v)
            if v:
                a["roi_p10"] = round(v[int(len(v) * 0.1)], 1)
                a["roi_median"] = round(statistics.median(v), 1)
                a["roi_p90"] = round(v[min(len(v) - 1, int(len(v) * 0.9))], 1)
            else:
                a["roi_p10"] = a["roi_median"] = a["roi_p90"] = None
        hyp = [dict(r) for r in con.execute(
            "SELECT * FROM hypotheses ORDER BY cle").fetchall()]
        # regroupement thematique pour l'affichage
        groupes = [
            ("Prix de l'énergie (TTC)", "prix_kwh_"),
            ("Facteurs d'émission CO₂ (arrêté DPE 2021)", "co2_kwh_"),
            ("Répartition des usages & rendements", None),
            ("Financements — MaPrimeRénov' Copropriété", "mpr_"),
            ("Valeur verte", "valeur_verte_"),
            ("Contexte urbain — surcoût ITE/toiture par zone", "coef_urbain_"),
            ("Raccordement réseau de chaleur — coût fixe selon distance", "reseau_fixe_"),
            ("Prix immobilier médian par département (€/m²)", "prix_m2_"),
        ]
        divers = {"part_chauffage", "part_ecs", "autres_usages_ef_m2", "cop_pac",
                  "cop_pac_ecs", "rendement_reseau", "m2_par_logement"}
        hyp_groupes = []
        for titre, prefixe in groupes:
            if prefixe is None:
                lignes = [h for h in hyp if h["cle"] in divers]
            else:
                lignes = [h for h in hyp if h["cle"].startswith(prefixe)]
            # cle "lignes" et non "items" : "items" est une methode de dict, Jinja2
            # resout getattr() avant l'acces par cle et renverrait la methode liee
            hyp_groupes.append({"titre": titre, "lignes": lignes})
        return {"actions": actions, "hypotheses_groupes": hyp_groupes,
                "nb_hypotheses": len(hyp)}
    finally:
        con.close()
