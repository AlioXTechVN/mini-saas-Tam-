@echo off
cd /d %~dp0
echo === Mini-SaaS Parc Immo (Eneville) ===
echo Interface : http://localhost:8000   (jeton : demo-parcimmo)
echo API       : http://localhost:8000/docs
start "" http://localhost:8000
python -m uvicorn app:app --port 8000
