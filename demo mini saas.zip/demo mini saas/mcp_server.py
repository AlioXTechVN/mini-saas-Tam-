# -*- coding: utf-8 -*-
"""Serveur MCP du Parc Immo — expose la base du mini-SaaS a Claude Code / VS Code.

Detecte automatiquement via le fichier .mcp.json a la racine du projet.
Outils : stats_parc, chercher_copros, fiche_copro, maj_gestion, importer_fichier, requete_sql.
Meme base SQLite que l'app web (data/parc.db) ; ecritures journalisees (source=mcp).
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from mcp.server.fastmcp import FastMCP

import db

mcp = FastMCP("parc-immo")


def _json(obj):
    return json.dumps(obj, ensure_ascii=False, indent=1, default=str)


@mcp.tool()
def stats_parc() -> str:
    """KPIs du parc : nb copros/bâtiments/logements, DPE, passoires, fioul, îlots de chaleur,
    RNC, répartitions par étiquette/énergie/statut de gestion."""
    return _json(db.stats_parc())


@mcp.tool()
def chercher_copros(recherche: str = None, departement: str = None, classe_dpe: str = None,
                    energie: str = None, tantiemes_min: float = None, expo_icu: str = None,
                    expo_argile: str = None, statut: str = None, tri: str = "score",
                    limite: int = 20, page: int = 1) -> str:
    """Recherche des copropriétés du Parc Immo. Retour : {total, page, limite, resultats:[...]}.
    Chaque résultat inclut pire_dpe, dpe_immeuble (vrai DPE à l'immeuble, estimation M3 depuis
    les DPE logements, ou estimation IA), source_dpe (DPE immeuble | DPE estimé à partir des
    DPE logements | DPE estimé par l'IA - fiabilité x%), fiabilite_dpe (fiabilité à ±1 classe :
    83-98 selon le nb de DPE logements pour M3, 84-90 selon les livraisons DLE pour l'IA ;
    null si vrai DPE), risque_passoire (1 = classe estimée A-E mais ≥20 % des DPE logements
    en F/G), energie_princ (énergie dominante, réelle ou estimée IA — voir energie_reelle
    et fiabilite_energie), expo_niveau (confort d'été) et argile_niveau (retrait-gonflement
    des argiles, aléa BDNB : 0=NC, 1=Faible, 2=Moyen, 3=Fort — pire bâtiment de la copro).
    Les filtres classe_dpe, energie, expo_icu et expo_argile portent sur les valeurs
    RETOURNÉES (affichées).
    - recherche : texte libre (nom, adresse, ville, réf)
    - departement : '75', '92'…  · classe_dpe : 'A'..'G' — filtre sur la classe dpe_immeuble
      retournée (pire bâtiment de la copro, vrai DPE prioritaire, sinon estimation)
    - energie : gaz | electricite | fioul | reseau de chaleur — énergie DOMINANTE de la copro
    - tantiemes_min : ex. 0.5 pour le focus Parc Immo majoritaire
    - expo_icu : Forte | Moyenne | Modérée — niveau du PIRE bâtiment (badge affiché)
    - expo_argile : Fort | Moyen | Faible — aléa retrait-gonflement des argiles (pire bâtiment)
    - statut : nouveau | a_etudier | audit_lance | travaux_votes | travaux_en_cours | termine
    - tri : score (priorité) | icu | tantiemes | ville | ref · pagination : limite + page"""
    return _json(db.chercher_copros(
        recherche=recherche, dep=departement, classe_dpe=classe_dpe, energie=energie,
        tantiemes_min=tantiemes_min, expo_icu=expo_icu, expo_argile=expo_argile,
        statut=statut, tri=tri, limite=limite, page=page))


@mcp.tool()
def fiche_copro(ref: str) -> str:
    """Fiche complète d'une copropriété par sa réf (ex. '1330.1') ou son row_id :
    identité, tantièmes, bâtiments BDNB (DPE, énergie, ICU, RNC), gestion, données importées,
    historique des modifications."""
    c = db.fiche_copro(ref)
    return _json(c) if c else _json({"erreur": f"Copro introuvable : {ref}"})


@mcp.tool()
def maj_gestion(ref: str, champ: str, valeur: str, motif: str = None) -> str:
    """Met à jour un champ ÉDITABLE d'une copro (journalisé, source=mcp).
    Champs autorisés : statut (nouveau|a_etudier|audit_lance|travaux_votes|travaux_en_cours|termine),
    note, contact_syndic, tantiemes_bailleur (0-1), nb_logt.
    Les données BDNB sont en lecture seule."""
    if champ in ("tantiemes_bailleur", "nb_logt"):
        try:
            valeur = float(valeur)
        except ValueError:
            return _json({"ok": False, "erreur": f"Valeur numérique attendue pour {champ}"})
    return _json(db.maj_gestion(ref, champ, valeur, motif, source="mcp"))


@mcp.tool()
def importer_fichier(chemin: str) -> str:
    """Importe un fichier CSV/Excel dans le SaaS (colonne ref ou row_id obligatoire).
    Colonnes tantiemes_bailleur/nb_logt/statut/note/contact_syndic : mise à jour directe ;
    autres colonnes : stockées avec provenance et visibles sur les fiches."""
    return _json(db.importer_fichier(chemin, source="mcp"))


@mcp.tool()
def plan_decarbonation(ref: str) -> str:
    """Plan de décarbonation d'une copro (réf ou row_id) : scénarios S1 Gestes
    essentiels / S2 Systèmes performants / S3 Rénovation globale — coût, aides CEE +
    MaPrimeRénov' Copro, reste à charge, gain énergie %, économies €/an, tCO2 évitées,
    ROI, classe avant/après, quote_part_bailleur (reste à charge × tantièmes),
    argumentaire de consensus AG. Règle Parc Immo : seuls les bâtiments classés E, F ou G
    sont chiffrés (D ou mieux : pas de gestes prioritaires à ce stade)."""
    c = db.fiche_copro(ref)
    if not c:
        return _json({"erreur": f"Copro introuvable : {ref}"})
    if not c.get("scenarios"):
        return _json({"info": "Pas de scénario calculé (hors focus tantièmes >= 50 % "
                              "ou aucune action éligible)."})
    return _json({"ref": c["ref"], "nom": c.get("nom_copro"),
                  "scenarios": c["scenarios"], "actions": c["plan_actions"]})


@mcp.tool()
def requete_sql(sql: str) -> str:
    """Exécute une requête SQL en LECTURE SEULE (SELECT uniquement) sur la base du parc.
    Tables : copros, batiments, liens, gestion, dpe_logements, conso_dle, icu_copros,
    prioritaires, imports, donnees_importees, audit_log. Limité à 200 lignes."""
    s = sql.strip().rstrip(";")
    if not s.lower().startswith("select") or ";" in s:
        return _json({"erreur": "SELECT unique uniquement (lecture seule)."})
    con = db.connect()
    try:
        rows = con.execute(f"SELECT * FROM ({s}) LIMIT 200").fetchall()
        return _json([dict(r) for r in rows])
    except Exception as e:
        return _json({"erreur": str(e)})
    finally:
        con.close()


if __name__ == "__main__":
    sys.stderr.write("Serveur MCP parc-immo demarre (stdio)\n")
    mcp.run()
