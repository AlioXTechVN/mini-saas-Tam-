# -*- coding: utf-8 -*-
"""Anonymise parc.db pour en faire un demonstrateur generique (marque "Parc Immo",
plus aucune reference a in'li ni aux vraies coproprietes/adresses/immatriculations).
A executer UNE SEULE FOIS sur la copie de la base dans ce dossier demo (jamais sur
la base originale du projet INLI).
"""
import random
import re
import sqlite3
import string

random.seed(42)

DB = "data/parc.db"
con = sqlite3.connect(DB)
cur = con.cursor()

# ---------------- generateurs de donnees fictives ----------------
NOMS_RESIDENCE = [
    "LES TILLEULS", "LE HAMEAU VERT", "LE CLOS FLEURI", "LES JARDINS DE LA PAIX",
    "LE PARC DES CERISIERS", "LA CLAIRIERE", "LES ACACIAS", "LE VAL FLEURI",
    "LES GLYCINES", "LA RESIDENCE DU LAC", "LE CLOS DES VIGNES", "LES ERABLES",
    "LE HAMEAU DES SOURCES", "LA VILLA DES PINS", "LES CHENES", "LE SQUARE DES ROSIERS",
    "LA RESIDENCE DES CHAMPS", "LE CLOS SAINT-MARTIN", "LES MAGNOLIAS",
    "LE DOMAINE DES PEUPLIERS", "LES CAMELIAS", "LE PARC SAINT-LOUIS",
    "LA RESIDENCE DES TERRASSES", "LE CLOS DU MOULIN", "LES BOULEAUX",
    "LE HAMEAU FLEURI", "LA VILLA DES ROSIERS", "LES PLATANES", "LE CLOS DES ROSES",
    "LA RESIDENCE DU PARC", "LE VAL D'AZUR", "LES MARRONNIERS", "LE CLOS SAINT-JEAN",
    "LA RESIDENCE VERTE", "LE HAMEAU DU CHATEAU", "LES SAULES", "LE PARC FLEURI",
]
TYPES_VOIE = ["Rue", "Avenue", "Boulevard", "Allée", "Impasse", "Square", "Chemin", "Place"]
NOMS_VOIE = [
    "des Lilas", "de la République", "des Fleurs", "Victor Hugo", "du Moulin",
    "de la Gare", "des Écoles", "de la Liberté", "du Stade", "des Vignes",
    "du Château", "de la Mairie", "des Peupliers", "de la Fontaine",
    "du 8 Mai 1945", "Jean Jaurès", "de la Paix", "des Tilleuls", "du Parc",
    "des Acacias", "Pasteur", "Jean Moulin", "de Verdun", "des Sports",
    "du Général de Gaulle", "des Roses", "de la Résistance", "des Marronniers",
]
PREFIXES_COPRO = [
    "SDC RESIDENCE {nom}", "SYNDICAT PRINCIPAL - RESIDENCE {nom}",
    "SDC {nom}", "RESIDENCE {nom}", "ASL {nom}", "SYNDICAT DES COPROPRIETAIRES {nom}",
]


def fake_adresse(seed):
    rnd = random.Random(seed)
    num = rnd.randint(1, 180)
    return f"{num} {rnd.choice(TYPES_VOIE)} {rnd.choice(NOMS_VOIE)}"


def fake_nom_copro(seed):
    rnd = random.Random(seed)
    nom = rnd.choice(NOMS_RESIDENCE)
    return rnd.choice(PREFIXES_COPRO).format(nom=nom)


def fake_bg_id(seed):
    rnd = random.Random(seed)
    grp = lambda: "".join(rnd.choices(string.ascii_uppercase + string.digits, k=4))
    return f"bdnb-bg-{grp()}-{grp()}-{grp()}"


def fake_rnc(seed):
    rnd = random.Random(seed)
    lettres = "".join(rnd.choices(string.ascii_uppercase, k=2))
    chiffres = rnd.randint(0, 9999999)
    return f"{lettres}{chiffres:07d}"


def fake_dpe_id(seed):
    rnd = random.Random(seed)
    return (f"{rnd.randint(1000, 9999)}"
            f"{rnd.choice(string.ascii_uppercase)}"
            f"{rnd.randint(0, 9999999):07d}"
            f"{rnd.choice(string.ascii_uppercase)}")


print("1) Remplacement des noms/adresses de copropriétés...")
rows = cur.execute("SELECT row_id FROM copros").fetchall()
for (rid,) in rows:
    nom = fake_nom_copro(rid)
    adr = fake_adresse(rid * 7 + 1)
    cur.execute("UPDATE copros SET nom_copro=?, adresse=? WHERE row_id=?", (nom, adr, rid))
    cur.execute("UPDATE icu_copros SET nom_copro=? WHERE row_id=?", (nom, rid))
print(f"   {len(rows)} copropriétés renommées.")

print("2) Remplacement des identifiants de bâtiments (BDNB) — remappage cohérent...")
bg_ids = [r[0] for r in cur.execute("SELECT batiment_groupe_id FROM batiments").fetchall()]
mapping = {bg: fake_bg_id(hash(bg) & 0xFFFFFFFF) for bg in bg_ids}
# garantie d'unicité (collision quasi impossible, mais on verifie)
assert len(set(mapping.values())) == len(mapping), "collision d'identifiants generes"
for table in ["batiments", "liens", "dpe_logements", "conso_dle", "plan_actions"]:
    cur.execute(f"SELECT rowid, batiment_groupe_id FROM {table}")
    for rowid, bg in cur.fetchall():
        cur.execute(f"UPDATE {table} SET batiment_groupe_id=? WHERE rowid=?", (mapping[bg], rowid))
print(f"   {len(bg_ids)} identifiants de bâtiments remappés dans 5 tables.")

print("3) Remplacement des adresses BAN et immatriculations RNC...")
rows = cur.execute("SELECT rowid, batiment_groupe_id FROM batiments").fetchall()
for rowid, bg_new in rows:
    adr = fake_adresse(hash(bg_new) & 0xFFFF)
    rnc = fake_rnc(hash(bg_new) & 0xFFFF ^ 0x55)
    nom = fake_nom_copro(hash(bg_new) & 0xFFFF ^ 0xAA)
    cur.execute("""UPDATE batiments SET adresse_ban=?, rnc_immat_finale=?,
                   rnc_numero_immat_principal=?, rnc_l_nom_copro=?
                   WHERE rowid=?""", (adr, rnc, rnc, nom, rowid))
print(f"   {len(rows)} bâtiments : adresse BAN + immat RNC anonymisées.")

print("4) Remplacement des identifiants DPE logements...")
rows = cur.execute("SELECT rowid FROM dpe_logements").fetchall()
for i, (rowid,) in enumerate(rows):
    cur.execute("UPDATE dpe_logements SET identifiant_dpe=? WHERE rowid=?",
                (fake_dpe_id(i), rowid))
print(f"   {len(rows)} DPE logements renumérotés.")

print("5) Purge des données de gestion/audit/import (demo repart propre)...")
for table in ["gestion", "audit_log", "imports", "donnees_importees"]:
    cur.execute(f"DELETE FROM {table}")
print("   Tables gestion/audit_log/imports/donnees_importees vidées.")

con.commit()
print("Sauvegarde OK.")
