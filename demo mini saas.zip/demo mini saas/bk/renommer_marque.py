# -*- coding: utf-8 -*-
"""Renomme les colonnes techniques *_inli et retire toute mention "in'li"/INLI du
code et des templates, remplacee par la marque fictive "Parc Immo" (demonstrateur
generique). A executer une seule fois apres anonymiser.py.
"""
import glob
import os

# ordre important : du plus specifique au plus general, pour eviter les
# remplacements partiels indesirables.
REMPLACEMENTS = [
    ("focus50_roi_vv_inli", "focus50_roi_vv_bailleur"),
    ("focus50_eur_an_inli", "focus50_eur_an_bailleur"),
    ("focus50_vv_inli", "focus50_vv_bailleur"),
    ("quote_part_inli", "quote_part_bailleur"),
    ("tantiemes_inli", "tantiemes_bailleur"),
    ("logements_inli", "logements_bailleur"),
    ("nb_logt_inli", "nb_logt_bailleur"),
    ("ref_inli", "ref"),
    ("INLI_TOKEN", "PARCIMMO_TOKEN"),
    ("inli-demo", "demo-parcimmo"),
    ("parc-inli", "parc-immo"),
    ("Parc in'li", "Parc Immo"),
    ("parc in'li", "Parc Immo"),
    ("in'li majoritaire", "Parc Immo majoritaire"),
    ("in'li lab", "demo lab"),
    ("logements in'li", "logements Parc Immo"),
    ("tantièmes in'li", "tantièmes Parc Immo"),
    ("Tantièmes in'li", "Tantièmes Parc Immo"),
    ("réf in'li", "réf"),
    ("reste à charge in'li", "reste à charge Parc Immo"),
    ("Quote-part in'li", "Quote-part Parc Immo"),
    ("quote-part in'li", "quote-part Parc Immo"),
    ("valeur verte in'li", "valeur verte Parc Immo"),
    ("investissement d'in'li", "investissement de Parc Immo"),
    ("porté par in'li", "porté par Parc Immo"),
    ("portée par in'li", "portée par Parc Immo"),
    ("pour in'li", "pour Parc Immo"),
    ("règle in'li", "règle Parc Immo"),
    ("Règle in'li", "Règle Parc Immo"),
    ("demande in'li", "demande du client"),
    ("focus in'li", "focus Parc Immo"),
    ("Focus in'li", "Focus Parc Immo"),
    ("d'in'li", "de Parc Immo"),
    ("d’in’li", "de Parc Immo"),
    ("in'li", "Parc Immo"),
    ("IN'LI", "PARC IMMO"),
    ("INLI", "PARCIMMO"),
]

FICHIERS = (["db.py", "app.py", "mcp_server.py", "lancer.bat"]
            + glob.glob("templates/*.html"))

for chemin in FICHIERS:
    if not os.path.exists(chemin):
        continue
    with open(chemin, encoding="utf-8") as f:
        texte = f.read()
    origine = texte
    for ancien, nouveau in REMPLACEMENTS:
        texte = texte.replace(ancien, nouveau)
    if texte != origine:
        with open(chemin, "w", encoding="utf-8") as f:
            f.write(texte)
        print(f"modifie : {chemin}")
    else:
        print(f"inchange : {chemin}")

print("Termine.")
