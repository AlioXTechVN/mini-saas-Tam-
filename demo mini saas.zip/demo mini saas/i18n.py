# -*- coding: utf-8 -*-
"""Internationalisation (FR/EN) du demonstrateur Parc Immo. Deux mecanismes :
1) TEXT : dictionnaire de libelles d'interface statiques, utilise via t(lang, cle).
2) Traducteurs de contenu genere/stocke en base (noms de scenario, familles d'actions,
   catalogue de gestes, groupes d'hypotheses, argumentaire de consensus auto-genere) :
   la donnee reste en francais en base, la traduction est appliquee a l'affichage.
"""
import re

LANGUES = ["fr", "en"]

TEXT = {
    # ---- navigation / structure ----
    "nav_dashboard": {"fr": "Tableau de bord", "en": "Dashboard"},
    "nav_copros": {"fr": "Copropriétés", "en": "Properties"},
    "nav_gestes": {"fr": "Gestes de décarbonation", "en": "Decarbonation measures"},
    "nav_import": {"fr": "Import", "en": "Import"},
    "nav_api": {"fr": "API", "en": "API"},
    "footer": {"fr": "POC Eneville · demo lab", "en": "Eneville POC · demo lab"},

    # ---- login ----
    "login_titre_page": {"fr": "Connexion · Parc Immo", "en": "Sign in · Parc Immo"},
    "login_connexion": {"fr": "Connexion au démonstrateur", "en": "Sign in to the demo"},
    "login_jeton_placeholder": {"fr": "Jeton d'accès", "en": "Access token"},
    "login_entrer": {"fr": "Entrer", "en": "Sign in"},
    "login_jeton_invalide": {"fr": "Jeton invalide.", "en": "Invalid token."},
    "login_jeton_defaut_1": {"fr": "Jeton par défaut du démonstrateur : demo-parcimmo",
                              "en": "Default demo token: demo-parcimmo"},
    "login_jeton_defaut_2": {"fr": "(modifiable via la variable d'environnement PARCIMMO_TOKEN).",
                              "en": "(configurable via the PARCIMMO_TOKEN environment variable)."},

    # ---- dashboard ----
    "dash_eyebrow": {"fr": "Tableau de bord", "en": "Dashboard"},
    "dash_titre": {"fr": "Le parc en un coup d'œil", "en": "The portfolio at a glance"},
    "dash_kpi_copros": {"fr": "copropriétés", "en": "properties"},
    "dash_kpi_batiments": {"fr": "bâtiments BDNB", "en": "buildings (national database)"},
    "dash_kpi_logements": {"fr": "logements Parc Immo", "en": "Parc Immo units"},
    "dash_kpi_focus50": {"fr": "copros Parc Immo majoritaire (≥ 50 %)",
                          "en": "properties where Parc Immo is majority owner (≥ 50%)"},
    "dash_kpi_efg": {"fr": "bâtiments E-F-G en DPE immeuble", "en": "buildings rated E-F-G"},
    "dash_kpi_efg_detail": {"fr": "{passoires} passoires + {risque} risques ⚠",
                             "en": "{passoires} energy sieves + {risque} at-risk ⚠"},
    "dash_kpi_fioul": {"fr": "bâtiments au fioul (énergie réelle et estimée)",
                        "en": "buildings heated by oil (actual and estimated)"},
    "dash_kpi_icu": {"fr": "confort d'été : bâtiments à risque fort",
                      "en": "summer comfort: high-risk buildings"},
    "dash_kpi_argile_title": {"fr": "Aléa retrait-gonflement des argiles (BDNB) : risque de fissures "
                                     "sur les fondations en cas d'alternance sécheresse/réhydratation "
                                     "des sols argileux.",
                               "en": "Clay shrink-swell hazard (national database): risk of foundation "
                                     "cracking from alternating drought/rehydration of clay soils."},
    "dash_kpi_argile": {"fr": "risque argile fort ({n} copros)", "en": "high clay-soil risk ({n} properties)"},
    "dash_kpi_rnc": {"fr": "copros avec immatriculation RNC",
                      "en": "properties with official registry number"},
    "dash_dpe_titre": {"fr": "Étiquettes DPE immeuble (réelles et estimées)",
                        "en": "Building energy ratings (actual and estimated)"},
    "dash_energie_titre": {"fr": "Énergie principale de chauffage (réelle et estimée IA)",
                            "en": "Main heating energy source (actual and AI-estimated)"},
    "dash_decarbonation": {"fr": "Décarbonation", "en": "Decarbonation"},
    "dash_co2_lab": {"fr": "CO₂e émis par an — {pct} % du parc : {doc} bâtiments documentés (DPE) "
                            "+ {est} estimés ({pct2} % du total)",
                      "en": "tCO₂e emitted per year — {pct}% of the portfolio: {doc} buildings with "
                            "records (EPC) + {est} estimated ({pct2}% of total)"},
    "dash_action_lab": {"fr": "copros en action de décarbonation (audit → travaux → terminé)",
                         "en": "properties with decarbonation action under way (audit → works → done)"},
    "dash_plan_lab": {"fr": "plan de décarbonation v1 : scénario Rénovation globale chiffré sur "
                             "{n} copros (détail et scénarios comparés sur chaque fiche)",
                       "en": "decarbonation plan v1: Full Renovation scenario costed for {n} "
                             "properties (details and compared scenarios on each property page)"},
    "dash_focus_titre": {"fr": "Plan de décarbonation v1 — focus copros tantièmes Parc Immo ≥ 50 %",
                          "en": "Decarbonation plan v1 — focus on properties ≥ 50% Parc Immo owned"},
    "dash_focus_note": {"fr": "Potentiel du scénario Rénovation globale (le plus ambitieux du plan v1) "
                               "sur les {n} copros majoritaires Parc Immo chiffrées (bâtiments classés "
                               "E, F ou G).",
                         "en": "Potential of the Full Renovation scenario (the most ambitious in plan "
                               "v1) across the {n} Parc Immo-majority properties costed (buildings "
                               "rated E, F or G)."},
    "dash_focus_tco2": {"fr": "potentiel de décarbonation (tCO₂e évité/an)",
                         "en": "decarbonation potential (tCO₂e avoided/year)"},
    "dash_focus_eur_an": {"fr": "potentiel d'économies d'énergie/an (−{mwh} MWh/an)",
                           "en": "potential energy savings/year (−{mwh} MWh/year)"},
    "dash_focus_cout_total": {"fr": "coût total de rénovation", "en": "total renovation cost"},
    "dash_focus_cout_title": {"fr": "Ordre de grandeur estimé du coût des travaux pour l'ensemble de "
                                     "la copropriété (tous copropriétaires, toute la copropriété).",
                               "en": "Estimated order of magnitude of works cost for the whole "
                                     "property (all co-owners, entire building)."},
    "dash_focus_financements": {"fr": "financements obtenables", "en": "available subsidies"},
    "dash_focus_financements_title": {"fr": "CEE (Certificats d'Économies d'Énergie) + MaPrimeRénov' "
                                             "Copropriété obtenus sur l'ensemble des travaux (toute la "
                                             "copropriété).",
                                       "en": "Energy-savings certificates (CEE) + MaPrimeRénov' "
                                             "Copropriété subsidy obtained across all works (entire "
                                             "property)."},
    "dash_focus_rac_total": {"fr": "reste à charge total (toute la copropriété)",
                              "en": "total remaining cost (whole property)"},
    "dash_focus_rac_total_title": {"fr": "Coût total − CEE − MaPrimeRénov', pour l'ensemble de chaque "
                                          "copropriété (tous copropriétaires confondus, avant "
                                          "répartition selon les tantièmes de Parc Immo).",
                                    "en": "Total cost − CEE − MaPrimeRénov', for each property as a "
                                          "whole (all co-owners combined, before splitting by Parc "
                                          "Immo's ownership share)."},
    "dash_focus_rac": {"fr": "dont part Parc Immo", "en": "of which Parc Immo's share"},
    "dash_focus_rac_title": {"fr": "Part du reste à charge total (colonne précédente) portée par "
                                    "Parc Immo, au prorata de ses tantièmes dans chaque copropriété — "
                                    "pas le reste à charge total, seulement la quote-part de Parc Immo.",
                              "en": "Share of the total remaining cost (previous tile) borne by Parc "
                                    "Immo, pro rata to its ownership share in each property — not the "
                                    "total remaining cost, only Parc Immo's portion of it."},
    "dash_focus_roi": {"fr": "ROI estimé", "en": "Estimated payback"},
    "dash_focus_roi_title": {"fr": "Retour sur investissement simple, toute la copropriété : reste à "
                                    "charge total ÷ économies d'énergie annuelles totales — sans tenir "
                                    "compte de la plus-value immobilière.",
                              "en": "Simple payback period, whole property: total remaining cost ÷ "
                                    "total annual energy savings — excluding property value gain."},
    "dash_focus_vv": {"fr": "prise de valeur « verte » après travaux", "en": "“green” value gain after works"},
    "dash_focus_vv_title": {"fr": "Gain de valeur immobilière lié aux classes DPE gagnées après "
                                   "travaux (~4 %/classe, plafonné à 3 classes — études Notaires de "
                                   "France), toute la copropriété. Quote-part Parc Immo estimée "
                                   "(prorata tantièmes) : {qp}.",
                             "en": "Property value gain linked to energy rating classes gained after "
                                   "works (~4%/class, capped at 3 classes — Notaires de France "
                                   "studies), whole property. Estimated Parc Immo share (pro rata "
                                   "ownership): {qp}."},
    "dash_focus_roivv": {"fr": "ROI avec valeur verte (Parc Immo)", "en": "Payback with green value (Parc Immo)"},
    "dash_focus_roivv_title": {"fr": "ROI net pour Parc Immo : (reste à charge Parc Immo − quote-part "
                                      "de la valeur verte Parc Immo) ÷ quote-part Parc Immo des "
                                      "économies d'énergie annuelles. Un ROI proche de 0 signifie que "
                                      "la plus-value immobilière couvre à elle seule l'investissement "
                                      "de Parc Immo.",
                                "en": "Net payback for Parc Immo: (Parc Immo's remaining cost − Parc "
                                      "Immo's share of green value) ÷ Parc Immo's share of annual "
                                      "energy savings. A payback near 0 means the property value gain "
                                      "alone covers Parc Immo's investment."},
    "dash_actions_titre": {"fr": "Actions de décarbonation — avancement de la gestion",
                            "en": "Decarbonation actions — management status"},
    "dash_actions_note": {"fr": "Statuts modifiables sur chaque fiche copro, via l'API ou via Claude "
                                 "Code (MCP) — ex. « passe la copro 1330.1 en travaux_votes ».",
                           "en": "Statuses can be changed on each property page, via the API or via "
                                 "Claude Code (MCP) — e.g. “set property 1330.1 to works_approved”."},
    "dash_lien_prioritaires": {"fr": "→ Voir les copropriétés prioritaires", "en": "→ View priority properties"},
    "dash_lien_icu": {"fr": "→ Confort d'été : copros à risque fort", "en": "→ Summer comfort: high-risk properties"},
    "dash_lien_focus": {"fr": "→ Focus Parc Immo majoritaire", "en": "→ Focus on Parc Immo-majority properties"},

    # ---- copros (recherche) ----
    "copros_eyebrow": {"fr": "Copropriétés", "en": "Properties"},
    "copros_titre": {"fr": "Recherche dans le parc", "en": "Search the portfolio"},
    "copros_q_placeholder": {"fr": "Nom, adresse, ville, réf…", "en": "Name, address, city, ref…"},
    "copros_dep": {"fr": "Département", "en": "District"},
    "copros_dpe_title": {"fr": "Filtre sur la classe affichée en colonne DPE immeuble : pire "
                                "bâtiment de la copro, vrai DPE ADEME prioritaire, sinon estimation "
                                "M3",
                          "en": "Filters on the class shown in the Building EPC column: worst "
                                "building in the property, real official EPC first, otherwise M3 "
                                "estimate"},
    "copros_dpe": {"fr": "DPE immeuble", "en": "Building EPC"},
    "copros_energie": {"fr": "Énergie", "en": "Energy"},
    "copros_icu": {"fr": "Expo. chaleur", "en": "Heat exposure"},
    "copros_argile_title": {"fr": "Aléa retrait-gonflement des argiles (BDNB)",
                             "en": "Clay shrink-swell hazard (national database)"},
    "copros_argile": {"fr": "Risque argile", "en": "Clay-soil risk"},
    "copros_statut": {"fr": "Statut gestion", "en": "Management status"},
    "copros_focus_label": {"fr": "tantièmes ≥ 50 %", "en": "ownership share ≥ 50%"},
    "copros_tri_score": {"fr": "Tri : priorité", "en": "Sort: priority"},
    "copros_tri_icu": {"fr": "Tri : expo. chaleur", "en": "Sort: heat exposure"},
    "copros_tri_tantiemes": {"fr": "Tri : tantièmes", "en": "Sort: ownership share"},
    "copros_tri_ville": {"fr": "Tri : ville", "en": "Sort: city"},
    "copros_filtrer": {"fr": "Filtrer", "en": "Filter"},
    "copros_resultats": {"fr": "{n} résultat(s) — affichage {debut}-{fin}.",
                          "en": "{n} result(s) — showing {debut}-{fin}."},
    "copros_th_ref": {"fr": "Réf", "en": "Ref"},
    "copros_th_copro": {"fr": "Copropriété", "en": "Property"},
    "copros_th_ville": {"fr": "Ville", "en": "City"},
    "copros_th_tantiemes": {"fr": "Tantièmes", "en": "Ownership share"},
    "copros_th_logts": {"fr": "Logts", "en": "Units"},
    "copros_th_dpe_title": {"fr": "Classe DPE à l'immeuble : vrai DPE ADEME, ou estimation Eneville "
                                   "M3 (conso EP + GES des DPE logements pondérées surface, double "
                                   "seuil 2021) — pire bâtiment",
                             "en": "Building energy rating: real official EPC, or Eneville M3 estimate "
                                   "(surface-weighted energy + emissions of unit-level EPCs, dual "
                                   "2021 threshold) — worst building"},
    "copros_th_dpe": {"fr": "DPE immeuble", "en": "Building EPC"},
    "copros_th_source_title": {"fr": "Provenance du DPE : DPE immeuble certifié, estimation depuis "
                                      "les DPE logements, ou estimation IA Eneville",
                                "en": "EPC source: certified building EPC, estimated from unit-level "
                                      "EPCs, or Eneville AI estimate"},
    "copros_th_source": {"fr": "Source DPE immeuble", "en": "Building EPC source"},
    "copros_th_fiab_title": {"fr": "Fiabilité à ±1 classe de l'estimation, mesurée sur la BDNB : "
                                    "83-98 % selon le nombre de DPE logements (M3), 84-90 % selon "
                                    "les livraisons d'énergie (IA). Vide pour les vrais DPE immeuble.",
                              "en": "Reliability within ±1 class, measured on the national database: "
                                    "83-98% depending on the number of unit-level EPCs (M3), 84-90% "
                                    "from energy delivery data (AI). Blank for real building EPCs."},
    "copros_th_fiab": {"fr": "Fiabilité DPE", "en": "EPC reliability"},
    "copros_th_confort_title": {"fr": "Exposition à la chaleur urbaine — indice Eneville v0 (0-100) : "
                                       "contexte urbain + minéralisation de la parcelle + "
                                       "vulnérabilité du bâti",
                                 "en": "Urban heat exposure — Eneville v0 index (0-100): urban "
                                       "context + parcel soil-sealing + building vulnerability"},
    "copros_th_confort": {"fr": "Confort d'été", "en": "Summer comfort"},
    "copros_th_argile_title": {"fr": "Aléa retrait-gonflement des argiles (BDNB) : risque de "
                                      "fissures sur les fondations en cas d'alternance "
                                      "sécheresse/réhydratation des sols argileux — pire bâtiment "
                                      "de la copro",
                                "en": "Clay shrink-swell hazard (national database): risk of "
                                      "foundation cracking from alternating drought/rehydration of "
                                      "clay soils — worst building in the property"},
    "copros_th_argile": {"fr": "Risque argile", "en": "Clay-soil risk"},
    "copros_th_rnc": {"fr": "Immat RNC", "en": "Registry no."},
    "copros_th_priorite_title": {"fr": "Score = 0,7 × points(DPE immeuble, réel ou estimé) + 0,3 × "
                                        "points(pire DPE des bâtiments) + points(énergie dominante) + "
                                        "taille (nb logements Parc Immo ÷ 50, plafonné à 2) + "
                                        "tantièmes Parc Immo (0-1). Points DPE : G=5 F=4 E=3 D=2 C=1 "
                                        "B=A=0. Points énergie : fioul/GPL=3 gaz=2 électricité=1 "
                                        "réseau de chaleur=0. Plus le score est élevé, plus la copro "
                                        "est prioritaire.",
                                  "en": "Score = 0.7 × points(building EPC, real or estimated) + 0.3 "
                                        "× points(worst building EPC) + points(dominant energy) + "
                                        "size (Parc Immo units ÷ 50, capped at 2) + Parc Immo "
                                        "ownership share (0-1). EPC points: G=5 F=4 E=3 D=2 C=1 B=A=0. "
                                        "Energy points: oil/LPG=3 gas=2 electricity=1 district "
                                        "heating=0. The higher the score, the higher the priority."},
    "copros_th_priorite": {"fr": "Priorité", "en": "Priority"},
    "copros_th_statut": {"fr": "Statut", "en": "Status"},
    "copros_diag_conseille": {"fr": "Plus de 20 % des DPE logements en F/G — diagnostique conseillé",
                               "en": "Over 20% of unit-level EPCs rated F/G — assessment recommended"},
    "copros_ia_title": {"fr": "modèle IA Eneville entraîné sur 337 090 bâtiments BDNB (features "
                               "fonciers, BDTopo, réseaux, livraisons d'énergie)",
                         "en": "Eneville AI model trained on 337,090 national-database buildings "
                               "(land, topography, networks, energy delivery features)"},
    "copros_ia_estime": {"fr": "estimé par IA", "en": "AI-estimated"},
    "copros_m3_title": {"fr": "(méthode M3 Eneville)", "en": "(Eneville M3 method)"},
    "copros_dpe_logements": {"fr": "DPE logements", "en": "Unit-level EPC"},
    "copros_energie_est_title": {"fr": "Énergie estimée par l'IA Eneville (exactitude mesurée sur "
                                        "73 561 bâtiments test)",
                                  "en": "Energy estimated by the Eneville AI (accuracy measured on "
                                        "73,561 test buildings)"},
    "copros_energie_est": {"fr": "(est. ~{pct} %)", "en": "(est. ~{pct}%)"},
    "copros_risque_fort_title": {"fr": "Exposition forte à la chaleur urbaine", "en": "High urban heat exposure"},
    "copros_risque_fort": {"fr": "Risque fort", "en": "High risk"},
    "copros_risque_moyen_title": {"fr": "Exposition moyenne à la chaleur urbaine", "en": "Medium urban heat exposure"},
    "copros_risque_moyen": {"fr": "Risque moyen", "en": "Medium risk"},
    "copros_risque_modere_title": {"fr": "Exposition modérée à la chaleur urbaine", "en": "Slight urban heat exposure"},
    "copros_risque_modere": {"fr": "Modéré", "en": "Slight"},
    "copros_argile_fort_title": {"fr": "Aléa retrait-gonflement des argiles fort", "en": "High clay shrink-swell hazard"},
    "copros_argile_fort": {"fr": "Fort", "en": "High"},
    "copros_argile_moyen_title": {"fr": "Aléa retrait-gonflement des argiles moyen", "en": "Medium clay shrink-swell hazard"},
    "copros_argile_moyen": {"fr": "Moyen", "en": "Medium"},
    "copros_argile_faible_title": {"fr": "Aléa retrait-gonflement des argiles faible", "en": "Low clay shrink-swell hazard"},
    "copros_argile_faible": {"fr": "Faible", "en": "Low"},
    "copros_precedent": {"fr": "← Précédent", "en": "← Previous"},
    "copros_page": {"fr": "page {n}", "en": "page {n}"},
    "copros_suivant": {"fr": "Suivant →", "en": "Next →"},

    # ---- fiche ----
    "fiche_eyebrow": {"fr": "Fiche copropriété", "en": "Property page"},
    "fiche_aucune_immat": {"fr": "aucune immatriculation trouvée (ASL/AFUL non soumises, ou copro "
                                  "à vérifier)",
                            "en": "no registration found (some legal forms are exempt, or the "
                                  "property needs checking)"},
    "fiche_immat_rnc": {"fr": "Immat RNC : ", "en": "Registry no.: "},
    "fiche_kpi_tantiemes": {"fr": "tantièmes Parc Immo", "en": "Parc Immo ownership share"},
    "fiche_kpi_logements": {"fr": "logements Parc Immo", "en": "Parc Immo units"},
    "fiche_kpi_batiments": {"fr": "bâtiment(s)", "en": "building(s)"},
    "fiche_kpi_confort": {"fr": "confort d'été — exposition chaleur urbaine (indice 0-100)",
                           "en": "summer comfort — urban heat exposure (0-100 index)"},
    "fiche_batiments_titre": {"fr": "Bâtiments", "en": "Buildings"},
    "fiche_th_adresse": {"fr": "Adresse BAN", "en": "Address"},
    "fiche_th_dpe": {"fr": "DPE", "en": "EPC"},
    "fiche_th_ges": {"fr": "GES", "en": "GHG"},
    "fiche_th_dpe_immeuble_title": {"fr": "Vrai DPE ADEME à l'immeuble, ou estimation Eneville M3 "
                                           "depuis les DPE logements (fiabilité selon leur nombre)",
                                     "en": "Real official building EPC, or Eneville M3 estimate from "
                                           "unit-level EPCs (reliability depends on their number)"},
    "fiche_th_dpe_immeuble": {"fr": "DPE immeuble", "en": "Building EPC"},
    "fiche_th_energie": {"fr": "Énergie", "en": "Energy"},
    "fiche_th_annee": {"fr": "Année", "en": "Year"},
    "fiche_th_confort": {"fr": "Confort été", "en": "Summer comfort"},
    "fiche_th_argile_title": {"fr": "Aléa retrait-gonflement des argiles (BDNB) : risque de fissures "
                                     "sur les fondations en cas d'alternance sécheresse/réhydratation "
                                     "des sols argileux",
                               "en": "Clay shrink-swell hazard (national database): risk of "
                                     "foundation cracking from alternating drought/rehydration of "
                                     "clay soils"},
    "fiche_th_argile": {"fr": "Risque argile", "en": "Clay-soil risk"},
    "fiche_th_match": {"fr": "Match", "en": "Match"},
    "fiche_maps": {"fr": "Voir sur Google Maps", "en": "View on Google Maps"},
    "fiche_dpe_immeuble_badge": {"fr": "DPE immeuble", "en": "Building EPC"},
    "fiche_dpe_m3_title": {"fr": " — méthode M3 depuis {n} DPE logements", "en": " — M3 method from {n} unit-level EPCs"},
    "fiche_dpe_ia_title": {"fr": " — modèle IA Eneville (sans aucun DPE disponible)", "en": " — Eneville AI model (no EPC available at all)"},
    "fiche_dpe_fiab_suffix": {"fr": " · fiabilité à ±1 classe", "en": " · reliability within ±1 class"},
    "fiche_dpe_ia_court": {"fr": "IA", "en": "AI"},
    "fiche_dpe_estime_court": {"fr": "estimé", "en": "estimated"},
    "fiche_a_estimer": {"fr": "à estimer (IA)", "en": "to be estimated (AI)"},
    "fiche_energie_est_title": {"fr": "Estimée par l'IA Eneville (exactitude mesurée sur bâtiments "
                                       "test BDNB)",
                                 "en": "Estimated by the Eneville AI (accuracy measured on national-"
                                       "database test buildings)"},
    "fiche_conso_note": {"fr": "Conso élec/gaz réelles et détail DPE logements accessibles via "
                                "l'API (/docs).",
                          "en": "Actual electricity/gas consumption and unit-level EPC detail "
                                "available via the API (/docs)."},
    "fiche_plan_titre": {"fr": "Plan de décarbonation — scénarios comparés (v1)",
                          "en": "Decarbonation plan — compared scenarios (v1)"},
    "fiche_plan_aucun_titre": {"fr": "Plan de décarbonation", "en": "Decarbonation plan"},
    "fiche_plan_aucun": {"fr": "Cette copropriété est classée D ou mieux — pas de gestes de "
                                "décarbonation prioritaires à ce stade.",
                          "en": "This property is already rated D or better — no priority "
                                "decarbonation measures at this stage."},
    "fiche_th_scenario": {"fr": "Scénario", "en": "Scenario"},
    "fiche_th_cout": {"fr": "Coût", "en": "Cost"},
    "fiche_th_aides": {"fr": "Aides (CEE + MPR)", "en": "Subsidies (CEE + MPR)"},
    "fiche_th_rac": {"fr": "Reste à charge", "en": "Remaining cost"},
    "fiche_th_qp_title": {"fr": "Part du reste à charge portée par Parc Immo = reste à charge × "
                                 "tantièmes Parc Immo. Le coût affiché reste celui estimé pour la "
                                 "copropriété entière (tous bâtiments liés).",
                           "en": "Share of the remaining cost borne by Parc Immo = remaining cost × "
                                 "Parc Immo ownership share. The cost shown remains the one "
                                 "estimated for the whole property (all linked buildings)."},
    "fiche_th_qp": {"fr": "Quote-part Parc Immo", "en": "Parc Immo's share"},
    "fiche_th_gain": {"fr": "Gain énergie", "en": "Energy savings"},
    "fiche_th_eco": {"fr": "Économies/an", "en": "Savings/year"},
    "fiche_th_co2": {"fr": "CO₂ évité/an", "en": "CO₂ avoided/year"},
    "fiche_th_roi": {"fr": "ROI", "en": "Payback"},
    "fiche_th_roivv_title": {"fr": "ROI intégrant la valeur verte : temps de retour du reste à "
                                    "charge NET du gain de valeur immobilière lié aux classes DPE "
                                    "gagnées (études Notaires de France : ~4 % de valeur par classe, "
                                    "plafonné à 3 classes, prix m² médian du département). "
                                    "« Immédiat » = le gain de valeur patrimoniale couvre à lui seul "
                                    "le reste à charge. Survolez la valeur pour voir le montant "
                                    "estimé.",
                              "en": "Payback including green value: time to recoup the remaining "
                                    "cost NET of the property value gain linked to energy rating "
                                    "classes gained (Notaires de France studies: ~4% value per "
                                    "class, capped at 3 classes, median price/m² for the district). "
                                    "“Immediate” = the property value gain alone covers the "
                                    "remaining cost. Hover the value to see the estimated amount."},
    "fiche_th_roivv": {"fr": "ROI valeur verte", "en": "Payback with green value"},
    "fiche_th_classe": {"fr": "Classe", "en": "Rating"},
    "fiche_immediat": {"fr": "immédiat", "en": "immediate"},
    "fiche_valeur_verte_title": {"fr": "Valeur verte estimée : {v}", "en": "Estimated green value: {v}"},
    "fiche_sortie_passoire_title": {"fr": "Sortie de passoire : bonus MPR +10 % inclus",
                                     "en": "Energy sieve exit: +10% MaPrimeRénov' bonus included"},
    "fiche_detail_resume": {"fr": "détail des actions et argumentaire", "en": "measure detail and consensus statement"},
    "fiche_th_action": {"fr": "Action", "en": "Measure"},
    "fiche_th_famille": {"fr": "Famille", "en": "Category"},
    "fiche_th_cee": {"fr": "CEE", "en": "CEE"},
    "fiche_regle_note": {"fr": "Chiffrage v1 forfaitaire (fourchettes ADEME/ANAH/observatoires, "
                                "hypothèses modifiables en base — table hypotheses). Règle Parc "
                                "Immo : seuls les bâtiments classés E, F ou G sont chiffrés. "
                                "MaPrimeRénov' Copro : 30 % (gain ≥ 35 %) ou 45 % (≥ 50 %), bonus "
                                "+10 % sortie de passoire, plafond 25 k€/logt. À affiner par audit "
                                "énergétique.",
                          "en": "Flat-rate v1 costing (ADEME/ANAH/industry-observatory ranges, "
                                "assumptions editable in the database — hypotheses table). Parc "
                                "Immo rule: only buildings rated E, F or G are costed. "
                                "MaPrimeRénov' Copro: 30% (gain ≥ 35%) or 45% (≥ 50%), +10% bonus "
                                "for exiting energy-sieve status, capped at €25k/unit. To be refined "
                                "with an energy audit."},
    "fiche_import_titre": {"fr": "Données importées", "en": "Imported data"},
    "fiche_th_champ": {"fr": "Champ", "en": "Field"},
    "fiche_th_valeur": {"fr": "Valeur", "en": "Value"},
    "fiche_th_fichier": {"fr": "Fichier", "en": "File"},
    "fiche_th_date": {"fr": "Date", "en": "Date"},
    "fiche_gestion_titre": {"fr": "Gestion (éditable, journalisé)", "en": "Management (editable, logged)"},
    "fiche_statut": {"fr": "Statut : ", "en": "Status: "},
    "fiche_statut_inchange": {"fr": "— inchangé —", "en": "— unchanged —"},
    "fiche_statut_actuel": {"fr": "actuel : {s}", "en": "current: {s}"},
    "fiche_note": {"fr": "Note :", "en": "Note:"},
    "fiche_contact_syndic": {"fr": "Contact syndic : ", "en": "Property manager contact: "},
    "fiche_tantiemes_edit": {"fr": "Tantièmes Parc Immo (0-1) : ", "en": "Parc Immo ownership share (0-1): "},
    "fiche_enregistrer": {"fr": "Enregistrer", "en": "Save"},
    "fiche_derniere_maj": {"fr": "Dernière maj : {d} par {p}", "en": "Last updated: {d} by {p}"},
    "fiche_historique_titre": {"fr": "Historique", "en": "History"},
    "fiche_th_source": {"fr": "Source", "en": "Source"},
    "fiche_th_avant_apres": {"fr": "Avant → Après", "en": "Before → After"},
    "fiche_aucune_modif": {"fr": "Aucune modification enregistrée.", "en": "No changes recorded yet."},
    "fiche_enregistre_msg": {"fr": "Enregistré", "en": "Saved"},

    # ---- gestes ----
    "gestes_eyebrow": {"fr": "Référentiel méthodologique", "en": "Methodology reference"},
    "gestes_titre": {"fr": "Gestes de décarbonation", "en": "Decarbonation measures"},
    "gestes_intro": {"fr": "Catalogue des {n} actions mobilisées dans les plans de décarbonation, "
                            "avec leurs hypothèses de chiffrage.",
                      "en": "Catalogue of the {n} measures used in decarbonation plans, with their "
                            "costing assumptions."},
    "gestes_th_action": {"fr": "Action", "en": "Measure"},
    "gestes_th_cout_title": {"fr": "Fourchette basse–haute selon les références publiques. "
                                    "Certaines actions ont une part fixe par bâtiment (automate de "
                                    "régulation, branchement réseau).",
                              "en": "Low–high range from public references. Some measures include "
                                    "a fixed cost per building (control unit, network connection)."},
    "gestes_th_cout": {"fr": "Coût", "en": "Cost"},
    "gestes_th_cee_title": {"fr": "Certificats d'Économies d'Énergie — forfait indicatif par "
                                   "logement (fourchette basse–haute).",
                             "en": "Energy-savings certificates (CEE) — indicative flat rate per "
                                   "unit (low–high range)."},
    "gestes_th_cee": {"fr": "Financement CEE", "en": "CEE funding"},
    "gestes_th_gain_title": {"fr": "Réduction estimée sur l'usage concerné (chauffage, ECS…), "
                                    "modulée ensuite par l'état réel du bâtiment.",
                              "en": "Estimated reduction on the relevant use (heating, hot water…), "
                                    "then adjusted by the building's actual condition."},
    "gestes_th_gain": {"fr": "Gain énergie", "en": "Energy savings"},
    "gestes_th_duree": {"fr": "Durée de vie", "en": "Service life"},
    "gestes_th_eligibilite": {"fr": "Éligibilité", "en": "Eligibility"},
    "gestes_ref": {"fr": "Réf. : {s}", "en": "Ref.: {s}"},
    "gestes_fixe_bat": {"fr": "+ {v} fixe/bât.", "en": "+ {v} fixed/building"},
    "gestes_chgt_vecteur_title": {"fr": "Changement de générateur : le gain dépend du rendement du "
                                         "nouveau système (PAC COP 3, réseau de chaleur), calculé "
                                         "sur la consommation résiduelle.",
                                   "en": "Generator change: the gain depends on the efficiency of "
                                         "the new system (heat pump COP 3, district heating), "
                                         "calculated on the residual consumption."},
    "gestes_chgt_vecteur": {"fr": "chgt de vecteur", "en": "energy source change"},
    "gestes_hyp_titre": {"fr": "Hypothèses de calcul ({n} paramètres)",
                          "en": "Costing assumptions ({n} parameters)"},
    "gestes_hyp_note": {"fr": "Paramètres partagés par tous les scénarios. Sources : arrêté DPE "
                               "2021 (facteurs CO₂), observatoires de prix de l'énergie, "
                               "MaPrimeRénov' Copropriété 2026, études Notaires de France (valeur "
                               "verte).",
                         "en": "Parameters shared by all scenarios. Sources: 2021 EPC methodology "
                               "order (CO₂ factors), energy-price observatories, MaPrimeRénov' "
                               "Copropriété 2026, Notaires de France studies (green value)."},
    "gestes_th_parametre": {"fr": "Paramètre", "en": "Parameter"},
    "gestes_th_valeur": {"fr": "Valeur", "en": "Value"},
    "gestes_th_source": {"fr": "Source", "en": "Source"},
    "gestes_footer": {"fr": "Ces gestes se combinent en 3 scénarios (S1 Gestes essentiels, S2 "
                             "Systèmes performants, S3 Rénovation globale) chiffrés par "
                             "copropriété — voir chaque {lien}. Seuls les bâtiments classés E, F "
                             "ou G sont chiffrés (règle Parc Immo). MaPrimeRénov' Copro : 30 % du "
                             "HT (gain ≥ 35 %) ou 45 % (≥ 50 %), bonus +10 % pour une sortie de "
                             "passoire, plafond 25 k€/logement.",
                       "en": "These measures combine into 3 scenarios (S1 Essential Measures, S2 "
                             "High-Performance Systems, S3 Full Renovation) costed per property — "
                             "see each {lien}. Only buildings rated E, F or G are costed (Parc "
                             "Immo rule). MaPrimeRénov' Copro: 30% before tax (gain ≥ 35%) or 45% "
                             "(≥ 50%), +10% bonus for exiting energy-sieve status, capped at "
                             "€25k/unit."},
    "gestes_lien_fiche": {"fr": "fiche copropriété", "en": "property page"},

    # ---- import ----
    "import_eyebrow": {"fr": "Import de données", "en": "Data import"},
    "import_titre": {"fr": "Importer un fichier CSV ou Excel", "en": "Import a CSV or Excel file"},
    "import_bouton": {"fr": "Importer", "en": "Import"},
    "import_note": {"fr": "Le fichier doit contenir une colonne {ref} (ex. 1330.1) ou {row_id}. "
                           "Les colonnes {champs} mettent à jour directement les fiches "
                           "(journalisé). Toute autre colonne est conservée avec sa provenance et "
                           "affichée sur la fiche. Les données BDNB restent en lecture seule.",
                     "en": "The file must contain a {ref} column (e.g. 1330.1) or {row_id}. The "
                           "{champs} columns update property records directly (logged). Any other "
                           "column is kept with its source and shown on the property page. National-"
                           "database data remains read-only."},
    "import_reussi": {"fr": "Import réussi.", "en": "Import successful."},
    "import_resultat": {"fr": "{lignes} ligne(s) lue(s) · {champs} champ(s) mis à jour · {valeurs} "
                                "valeur(s) stockée(s) · {refs} réf(s) inconnue(s).",
                          "en": "{lignes} row(s) read · {champs} field(s) updated · {valeurs} "
                                "value(s) stored · {refs} unknown ref(s)."},
    "import_echec": {"fr": "Échec : {e}", "en": "Failed: {e}"},
    "import_historique_titre": {"fr": "Historique des imports", "en": "Import history"},
    "import_th_date": {"fr": "Date", "en": "Date"},
    "import_th_fichier": {"fr": "Fichier", "en": "File"},
    "import_th_source": {"fr": "Source", "en": "Source"},
    "import_th_lignes": {"fr": "Lignes", "en": "Rows"},
    "import_th_maj": {"fr": "Maj", "en": "Updated"},
    "import_th_stockees": {"fr": "Stockées", "en": "Stored"},
    "import_th_refs_inconnues": {"fr": "Réfs inconnues", "en": "Unknown refs"},
}


def t(lang, cle, **kwargs):
    """Traduit une cle d'interface. Repli sur le francais puis sur la cle elle-meme."""
    entree = TEXT.get(cle, {})
    chaine = entree.get(lang) or entree.get("fr") or cle
    return chaine.format(**kwargs) if kwargs else chaine


# ---------------- traduction de contenu genere/stocke en base ----------------

SCENARIO_NOM_EN = {
    "Gestes essentiels": "Essential Measures",
    "Systèmes performants": "High-Performance Systems",
    "Rénovation globale": "Full Renovation",
}

STATUT_LABELS = {
    "nouveau": {"fr": "nouveau", "en": "new"},
    "a_etudier": {"fr": "à étudier", "en": "to review"},
    "audit_lance": {"fr": "audit lancé", "en": "audit launched"},
    "travaux_votes": {"fr": "travaux votés", "en": "works approved"},
    "travaux_en_cours": {"fr": "travaux en cours", "en": "works in progress"},
    "termine": {"fr": "terminé", "en": "completed"},
}

ENERGIE_LABELS = {
    "gaz": {"fr": "gaz", "en": "gas"},
    "electricite": {"fr": "électricité", "en": "electricity"},
    "reseau de chaleur": {"fr": "réseau de chaleur", "en": "district heating"},
    "fioul": {"fr": "fioul", "en": "oil"},
    "gpl/butane/propane": {"fr": "gpl/butane/propane", "en": "LPG/butane/propane"},
}

FAMILLE_LABELS = {
    "Chauffage": {"fr": "Chauffage", "en": "Heating"},
    "ECS": {"fr": "ECS", "en": "Domestic hot water"},
    "Enveloppe": {"fr": "Enveloppe", "en": "Building envelope"},
    "Systèmes": {"fr": "Systèmes", "en": "Systems"},
    "Ventilation": {"fr": "Ventilation", "en": "Ventilation"},
}

MATCH_LABELS = {
    "EXACTE": {"fr": "EXACTE", "en": "EXACT"},
    "BONNE": {"fr": "BONNE", "en": "GOOD"},
    "APPROCHEE": {"fr": "APPROCHEE", "en": "APPROXIMATE"},
    "A_VERIFIER": {"fr": "A_VERIFIER", "en": "TO_CHECK"},
}

USAGE_LABELS = {
    "chauffage": {"fr": "chauffage", "en": "heating"},
    "ecs": {"fr": "ECS", "en": "DHW"},
    "chauffage+ecs": {"fr": "chauffage + ECS", "en": "heating + DHW"},
    "generateur": {"fr": "—", "en": "—"},
}

HYP_GROUPES_EN = {
    "Prix de l'énergie (TTC)": "Energy prices (incl. tax)",
    "Facteurs d'émission CO₂ (arrêté DPE 2021)": "CO₂ emission factors (2021 EPC methodology order)",
    "Répartition des usages & rendements": "Use breakdown & efficiencies",
    "Financements — MaPrimeRénov' Copropriété": "Subsidies — MaPrimeRénov' Copropriété",
    "Valeur verte": "Green value",
    "Contexte urbain — surcoût ITE/toiture par zone": "Urban context — external insulation/roof surcharge by zone",
    "Raccordement réseau de chaleur — coût fixe selon distance": "District heating connection — fixed cost by distance",
    "Prix immobilier médian par département (€/m²)": "Median property price by district (€/m²)",
}

ACTIONS_EN = {
    "RESEAU": {"nom": "District heating connection",
               "eligibilite": "network < 200 m and oil/gas heating (fixed cost shown is a generic "
                              "case; adjusted for actual distance — see reseau_fixe_* assumptions)"},
    "PAC": {"nom": "Collective heat pump (replaces oil/gas boiler)",
            "eligibilite": "oil heating (priority) or gas; no nearby network"},
    "ECSTH": {"nom": "Collective heat-pump or solar domestic hot water",
              "eligibilite": "existing collective domestic hot water"},
    "PLAN": {"nom": "Ground floor insulation",
             "eligibilite": "built before 2000, floor over basement/car park"},
    "TOIT": {"nom": "Roof/terrace insulation", "eligibilite": "built before 2000"},
    "ITE": {"nom": "External wall insulation", "eligibilite": "built before 1990 or rating ≥ D"},
    "MENUIS": {"nom": "High-performance double glazing", "eligibilite": "built before 1990"},
    "CALO": {"nom": "Heating/DHW pipe insulation",
             "eligibilite": "collective hydraulic heating (gas, oil, district network)"},
    "DESEMB": {"nom": "System flushing + hydraulic balancing",
               "eligibilite": "collective hydraulic heating"},
    "REGUL": {"nom": "Boiler-room controls/BMS + weather compensation",
              "eligibilite": "collective heating"},
    "ROBTH": {"nom": "Thermostatic radiator valves",
              "eligibilite": "collective hydraulic heating"},
    "VMC": {"nom": "Collective humidity-controlled ventilation",
            "eligibilite": "all buildings (ventilation retrofit)"},
}

_UNITE_COUT_EN = {"m2shab": "/sq.m living area", "logt": "/unit"}


def traduire_unite_cout(unite, lang):
    if lang != "en":
        return {"m2shab": "/m² hab.", "logt": "/logement"}.get(unite, "")
    return _UNITE_COUT_EN.get(unite, "")


HYP_CLE_LABELS = {
    "autres_usages_ef_m2": {"fr": "autres usages (élec., forfait)", "en": "other uses (elec., flat rate)"},
    "cop_pac": {"fr": "COP PAC collective", "en": "Collective heat pump COP"},
    "cop_pac_ecs": {"fr": "COP PAC ECS", "en": "Heat pump COP (DHW)"},
    "m2_par_logement": {"fr": "m² par logement (repli)", "en": "m² per unit (fallback)"},
    "mpr_bonus_passoire": {"fr": "bonus MaPrimeRénov' sortie passoire",
                            "en": "MaPrimeRénov' bonus (energy-sieve exit)"},
    "mpr_plafond_logt": {"fr": "plafond MaPrimeRénov'/logt", "en": "MaPrimeRénov' cap/unit"},
    "mpr_taux_gain35": {"fr": "taux MaPrimeRénov' (gain ≥ 35 %)", "en": "MaPrimeRénov' rate (gain ≥ 35%)"},
    "mpr_taux_gain50": {"fr": "taux MaPrimeRénov' (gain ≥ 50 %)", "en": "MaPrimeRénov' rate (gain ≥ 50%)"},
    "part_chauffage": {"fr": "part chauffage (conso totale)", "en": "heating share (total consumption)"},
    "part_ecs": {"fr": "part ECS (conso totale)", "en": "DHW share (total consumption)"},
    "rendement_reseau": {"fr": "rendement sous-station réseau", "en": "district heating substation efficiency"},
    "reseau_fixe_100_200m": {"fr": "coût fixe réseau (100-200 m)", "en": "district network fixed cost (100-200m)"},
    "reseau_fixe_moins100m": {"fr": "coût fixe réseau (< 100 m)", "en": "district network fixed cost (< 100m)"},
    "valeur_verte_max_classes": {"fr": "plafond classes valeur verte", "en": "green-value class cap"},
    "valeur_verte_pct_par_classe": {"fr": "gain valeur verte par classe", "en": "green value gain per class"},
}


def hyp_label(cle, lang):
    """Libelle lisible d'un parametre d'hypothese (cle technique -> libelle FR/EN)."""
    if cle in HYP_CLE_LABELS:
        return HYP_CLE_LABELS[cle][lang]
    for prefixe in ("prix_kwh_", "co2_kwh_"):
        if cle.startswith(prefixe):
            energie = cle[len(prefixe):]
            base = ENERGIE_LABELS.get(energie, {}).get(lang, energie)
            return base
    if cle.startswith("coef_urbain_"):
        code = cle[len("coef_urbain_"):]
        return f"zone {code}" if lang == "fr" else f"zone {code}"
    if cle.startswith("prix_m2_"):
        code = cle[len("prix_m2_"):]
        return f"dép. {code}" if lang == "fr" else f"district {code}"
    return cle.replace("_", " ")


# ---------------- traducteur de l'argumentaire (texte auto-genere) ----------------

# \d(?:[\d ]*\d)? : commence et finit toujours par un chiffre, ne mange jamais les
# espaces environnants (les montants ont des espaces milliers internes, ex. "2 842 560")
_RE_NUM = r"\d(?:[\d ]*\d)?"


def traduire_argumentaire_en(fr: str) -> str:
    """Traduit en anglais un argumentaire auto-genere (structure fixe, cf. moteur() de
    l'ancien pipeline de calcul). Les nombres sont preserves tels quels."""
    s = fr

    for nom_fr, nom_en in SCENARIO_NOM_EN.items():
        s = s.replace(f"Scénario {nom_fr} : ", f"{nom_en} scenario: ")

    s = re.sub(r"(\d+) % d'économie d'énergie estimée, ",
               r"\1% estimated energy savings, ", s)
    s = re.sub(rf"({_RE_NUM}) €/logt/an de charges en moins, ",
               lambda m: f"€{m.group(1).strip()}/unit/year in reduced charges, ", s)
    s = re.sub(r"−(\d+) tCO₂e/an\. Aides estimées (\d+) % ",
               r"−\1 tCO₂e/year. Estimated subsidies \2% ", s)
    s = re.sub(rf"\(CEE ({_RE_NUM}) € \+ MaPrimeRénov' Copro ({_RE_NUM}) €\), reste à charge ",
               lambda m: f"(CEE €{m.group(1).strip()} + MaPrimeRénov' Copro €{m.group(2).strip()}), "
                         f"remaining cost ", s)
    s = re.sub(rf"({_RE_NUM}) €/logt\. ", lambda m: f"€{m.group(1).strip()}/unit. ", s)

    s = s.replace(
        "Sortie de passoire atteinte (classe ", "Energy sieve status resolved (rating ")
    s = s.replace(
        ") : levée de l'interdiction de louer (G interdit depuis 2025, F en 2028) et "
        "revalorisation du bien. ",
        "): rental ban lifted (G banned since 2025, F in 2028) and increased property value. ")
    s = re.sub(
        r"Sortie de passoire à viser : l'immeuble est classé (\w), l'interdiction de location "
        r"approche\. ",
        r"Energy sieve status to resolve: the building is currently rated \1, and the rental ban "
        r"is approaching. ", s)

    s = re.sub(
        r"Bouquet renforcé \(gammes hautes d'isolation\) appliqué sur (\d+) bâtiment\(s\) pour "
        r"viser la classe D\. ",
        r"Enhanced package (high-end insulation) applied to \1 building(s) to target rating D. ", s)
    s = re.sub(
        r"Attention : la classe (\w) subsiste après rénovation globale malgré le bouquet renforcé "
        r"— étude thermique spécifique requise \(géométrie ou vecteur énergétique défavorable\)\. ",
        r"Note: rating \1 remains after full renovation despite the enhanced package — a dedicated "
        r"thermal study is required (unfavourable geometry or energy vector). ", s)

    s = re.sub(
        rf"Valeur verte estimée : \+({_RE_NUM}) € de valeur patrimoniale \((\d+) classe\(s\) DPE "
        rf"gagnée\(s\)\s+~4 %/classe — Notaires de France\) ; en l'intégrant\s+le retour sur "
        rf"investissement net tombe à ",
        lambda m: (f"Estimated green value gain: +€{m.group(1).strip()} in property value "
                   f"({m.group(2)} rating class(es) gained, ~4%/class — Notaires de France); "
                   f"factoring this in, the net payback period drops to "), s)
    s = s.replace("moins d'un an. ", "under one year. ")
    s = re.sub(r"(\d+) an\(s\)\. ", r"\1 year(s). ", s)

    s = s.replace(
        "Parc Immo détient la majorité des tantièmes : le vote en AG est sécurisé si "
        "l'argumentaire charges/valeur est partagé avec les copropriétaires minoritaires.",
        "Parc Immo holds the majority of ownership shares: the vote at the general assembly is "
        "secured if the cost/value case is shared with minority co-owners.")

    s = re.sub(
        rf" Quote-part Parc Immo du reste à charge : ({_RE_NUM}) € \(tantièmes (\d+) %\)\.",
        lambda m: (f" Parc Immo's share of the remaining cost: €{m.group(1).strip()} (ownership "
                   f"share {m.group(2)}%)."), s)

    return s


def argumentaire(texte_fr, lang):
    return texte_fr if lang != "en" else traduire_argumentaire_en(texte_fr)
